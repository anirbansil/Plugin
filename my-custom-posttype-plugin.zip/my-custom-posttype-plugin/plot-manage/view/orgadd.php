<?php
session_start();
global $wpdb;
if($_POST['submit']){
   
  // echo "<pre>";
  // print_r($_REQUEST);
  // echo "</pre>";

  // Plot Insert

  $no_of_box = count($_POST['no_of_box']);

  $plot_table = $wpdb->prefix.'plot';  

  $plot_data = array('plot' => $_POST['plot'], 'share' => $_POST['share'], 'holding_no' => $_POST['holding_no'], 'kotta' => $_POST['kotta'], 'area' => $_POST['area'], 'no_of_box' => $no_of_box);

  $plot_format = array('%s','%s','%s','%s','%s','%d');

  $plot_in = $wpdb->insert($plot_table,$plot_data,$plot_format);

  $plot_id = $wpdb->insert_id;

  // Plot Dag Insert 

  $dag_table = $wpdb->prefix.'plot_dag';

  $total_dag = count($_POST['dag_sl_no']);

  for ($dag_loop = 0; $dag_loop < $total_dag; $dag_loop++) { 

    $dag_data = array('plot_id' => $plot_id, 'dag_sl_no' => $_POST['dag_sl_no'][$dag_loop], 'dag_no' => $_POST['dag_no'][$dag_loop]);

    $dag_format = array('%d','%s','%s');

    $dag_in = $wpdb->insert($dag_table,$dag_data,$dag_format);
  }


  // Member Detail Insert

  //$password = md5('123456');

  for ($box_loop = 0; $box_loop < $no_of_box; $box_loop++) {

    $box_index = $_POST['no_of_box'][$box_loop]; 

    $count_member_name = count($_POST['member_title'][$box_index]); 

    for ($mem_loop = 0; $mem_loop < $count_member_name; $mem_loop++) {

      $mem_table = $wpdb->prefix.'plot_member_details';

      // $len = strlen($_POST['membership_no'][$box_index][0]);

      // if($len == 1){
      //   $login_id = 'N-000'.$_POST['membership_no'][$box_index][0];
      // }elseif ($len == 2) {
      //   $login_id = 'N-00'.$_POST['membership_no'][$box_index][0];
      // }elseif ($len == 3) {
      //   $login_id = 'N-0'.$_POST['membership_no'][$box_index][0];
      // }else {
      //   $login_id = 'N-'.$_POST['membership_no'][$box_index][0];
      // }  

      $mem_data = array('plot_id' => $plot_id, 'box_id' => $box_index, 'member_title' => $_POST['member_title'][$box_index][$mem_loop], 'first_name' => $_POST['first_name'][$box_index][$mem_loop], 'last_name' => $_POST['last_name'][$box_index][$mem_loop], 'father_name' => $_POST['father_name'][$box_index][0], 'type_of_member' => $_POST['type_of_member'][$box_index][0], 'date_of_reg' => $_POST['date_of_reg'][$box_index][0], 'being_no' => $_POST['being_no'][$box_index][0], 'membership_date' => $_POST['membership_date'][$box_index][0], 'membership_no' => $_POST['membership_no'][$box_index][0]);

      $mem_format = array('%d','%d','%s','%s','%s','%s','%d','%s','%s','%s','%s');

      $mem_in = $wpdb->insert($mem_table,$mem_data,$mem_format);

    }

    // Nominee Insert

    $count_nominee = count($_POST['nominee'][$box_index]);

    for ($nomi_loop = 0; $nomi_loop < $count_nominee; $nomi_loop++) {

      $nomi_table = $wpdb->prefix.'plot_member_nominees';  

      $nomi_data = array('plot_id' => $plot_id, 'box_id' => $box_index, 'nominee' => $_POST['nominee'][$box_index][$nomi_loop]);

      $nomi_format = array('%d','%d','%s');

      $nomi_in = $wpdb->insert($nomi_table,$nomi_data,$nomi_format);
    }

  }

  if($plot_in == 1 && $dag_in == 1 && $mem_in == 1 && $nomi_in == 1){

    $msg = "Plot Inset Successfull.";

  }else{
    echo "Something wrong, please check.";
  }
  
}

if(isset($_POST['exlsubmit'])){

    $msg = "Upload Successfull.";

    $uploadfile=$_FILES['uploadfile']['tmp_name'];



    require ( plugin_dir_path(__FILE__). '/PHPExcel/Classes/PHPExcel.php');

    require_once ( plugin_dir_path(__FILE__). '/PHPExcel/Classes/PHPExcel/IOFactory.php');



    $objExcel=PHPExcel_IOFactory::load($uploadfile);

    foreach($objExcel->getWorksheetIterator() as $worksheet)

    {

        $highestrow=$worksheet->getHighestRow();

        $highestcolumn=$worksheet->getHighestColumn();

        $column = PHPExcel_Cell::columnIndexFromString($highestcolumn);

        // echo $highestrow;

        $rowlimit = $highestrow-1;

        $collimit = $column-2;


        for($row=1;$row<=$highestrow;$row++)
        {
            if($row!=1){
            $plot=$worksheet->getCellByColumnAndRow(0,$row)->getValue();
            $share=$worksheet->getCellByColumnAndRow(1,$row)->getValue();
            $holding_no=$worksheet->getCellByColumnAndRow(2,$row)->getValue();
            $kotta=$worksheet->getCellByColumnAndRow(3,$row)->getValue();
            $area=$worksheet->getCellByColumnAndRow(4,$row)->getValue();
            $member_title=$worksheet->getCellByColumnAndRow(11,$row)->getValue();
            $first_name=$worksheet->getCellByColumnAndRow(12,$row)->getValue();
            $last_name=$worksheet->getCellByColumnAndRow(13,$row)->getValue();
            $father_name=$worksheet->getCellByColumnAndRow(14,$row)->getValue();
            $nominee=$worksheet->getCellByColumnAndRow(15,$row)->getValue();
            $type_of_member=$worksheet->getCellByColumnAndRow(16,$row)->getValue();
            $date_of_registration=$worksheet->getCellByColumnAndRow(17,$row)->getValue();
            if($date_of_registration!=""){
              $date_of_reg = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($date_of_registration));
            }else{
              $date_of_reg=0;
            }
            $being_no=$worksheet->getCellByColumnAndRow(18,$row)->getValue();
            $mbrshp_date=$worksheet->getCellByColumnAndRow(19,$row)->getValue();
            if($mbrshp_date!=""){
              $membership_date = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($mbrshp_date));
            }else{
              $membership_date=0;
            }
            $membership_no=$worksheet->getCellByColumnAndRow(20,$row)->getValue();

            if($type_of_member=="ALLOTEE"){
              $type_member=1;
            }elseif($type_of_member=="TRANSFEREE"){
              $type_member=2;
            }elseif($type_of_member=="NOMINEE"){
              $type_member=3;
            }else{
              $type_member=0;
            }

            $is_exsist_plot = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot where (`plot` = '". $plot ."')", ""), ARRAY_A);
            
            if(count($is_exsist_plot) < 1){
              if($plot!=""){
                $wpdb->insert("wp_plot", array(
                'plot'=>$plot,
                'share'=>$share,
                'holding_no'=>$holding_no,
                'kotta'=>$kotta,
                'area'=>$area,
                'no_of_box'=>0 ));
                $k=0;
              }
                $qurid = 'SELECT MAX(id) AS id FROM wp_plot';
                $maxid = $wpdb->get_var($qurid);
                // echo $maxid;
                $i=0;
                for($col=5;$col<=10;$col++)
                { $i++;
                    $dag=$worksheet->getCellByColumnAndRow($col,$row)->getValue();
                    if($dag!=""){
                        $wpdb->insert("wp_plot_dag", array(
                        "plot_id"=>$maxid,
                        "dag_sl_no"=>$i,
                        "dag_no"=>$dag));
                    }
                }
                $box_id = $row-1;
                $k++;
                // $is_exsist = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot_member_details where (`membership_no` = '". $membership_no ."')", ""), ARRAY_A);
                // if(count($is_exsist) < 1){
                    $wpdb->insert("wp_plot_member_details", array(
                    'plot_id'=>$maxid,
                    'box_id'=>$k,
                    'member_title'=>$member_title,
                    'first_name'=>$first_name,
                    'last_name'=>$last_name,
                    'father_name'=>$father_name,
                    'type_of_member'=>$type_member,
                    'date_of_reg'=>$date_of_reg,
                    'being_no'=>$being_no,
                    'membership_date'=>$membership_date,
                    'membership_no'=>$membership_no ));

                  if($nominee!=""){
                    $nominee = preg_replace('/\.$/', '', $nominee); //Remove dot at end if exists
                    $val = explode(',', $nominee); //split string into array seperated by ', '
                    foreach($val as $value) //loop over values
                    {
                      if($value!=""){
                        $wpdb->insert("wp_plot_member_nominees", array(
                        'plot_id'=>$maxid,
                        'box_id'=>$k,
                        'nominee'=>$value ));
                      }
                    }
                  }
                // }else{
                //     $membererror_log[] = $membership_no;
                // }
                $plotquery = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot_member_details where (`plot_id` = '". $maxid ."')", ""), ARRAY_A);

                $no_of_box = count($plotquery);
                $plot_table = $wpdb->prefix.'plot';   
                $data = [ 'no_of_box' => $no_of_box ]; 
                $where = [ 'id' =>$maxid ]; 
                $plot_in = $wpdb->update( $plot_table, $data, $where );

                $success_msg = "Plot Insert Successfully.";
              }else{
                $ploterror_log[] = $plot;
              }

            $is_exsist_plot = [];
            }
        }

    }

}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Add Plot</title>
    <meta name="viewport" content="width=device-width">
    <link rel="shortcut icon" type="image/x-icon" href="images/fav.png">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/easy-responsive-tabs.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/style.css">
</head>
<body>
    <div class="wrapper">
        
        <main class="site-main inner-main"> 

            <form class="" action="<?php esc_url( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data" method="post">
                <div class="container">
                  <div class="plot-heading-hlder">
                    <h2>Add Plot By Excel Sheet</h2>
                  </div> 
                  <div class="plot-frm-holder holderstl">
                      <div class="form-group row">

                          <label class="col-md-2">Select File</label>

                          <div class="col-md-6">

                              <input type="file" name="uploadfile" class="form-control valdtion" required=""/>

                          </div>
                          <div class="col-md-4">
                            <a href="<?php echo plugins_url('/plot-manage/view/'); ?>file/Demo.xlsx">Download Demo Excel Sheet</a>
                          </div>
                      </div>

                      <div class="form-group row">

                          <label class="col-md-2"></label>

                          <div class="col-md-10">

                              <input type="submit" name="exlsubmit" class="btn btn-primary">

                          </div>

                      </div>

                    <span class="msg" style="color: green;font-size: 20px;font-weight: 600;"><?php echo $success_msg; ?></span>
                    <div class="exist_show">
                    <?php
                    if($ploterror_log){
                        $all = [];
                        foreach ($ploterror_log as $key => $values) {
                           if($values != ''){
                             $all[] = $values;                         
                           }
                        } ?>
                        
                        <span style="color: #ffa500;"><?php echo implode(',',$all).' - Those Plots already exsist.'; ?></span>
                    <?php } ?>

                    <?php /*
                    if($membererror_log){
                        $allm = [];
                        foreach ($membererror_log as $keys => $mvalues) {
                           if($mvalues != ''){
                             $allm[] = $mvalues;                         
                           }
                        } ?>
                        
                        <span style="color: #ffa500;"><?php echo implode(',',$allm).' - Those Membership No. already exsist.'; ?></span>
                    <?php } */ ?>
                    </div>

                  </div>
              </div>
          </form>
          <form action="" method="POST">
            <section class="plot-sec">
                <div class="container">
                  <div class="plot-heading-hlder">
                    <h2>Add Plot</h2>
                    <!-- <br>
                    <span class="msg" style="color: green;font-size: 20px;font-weight: 600;">Plot Inset Successfully.</span> -->
                  </div>                 


                  <span class="append_mem_det"></span>

                  <div class="plot-frm-holder ap_mem_det_div">
                        <a href="javascript:void(0)" class="plot-repet-a mem_details_add"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>

                        <div class="tooltip-holder">
                          <span>
                            <i class="fa fa-info-circle" aria-hidden="true"></i>
                          </span>

                          <div class="toltip-cntnt">
                             Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                          </div>
                        </div>
                        <input type="hidden" name="no_of_box[]" class="no_of_box" value="1">
                        <div class="formdiv nomieni-frmdiv ">
                            <span class="filed_name">Member Name</span>
                            <div class="frmholder">
                               <div class="form-inline mem_name">
                                  <div class="form-group">
                                    <!-- <input type="text" name="member_title[]" class="valdtion"  placeholder="Salutation" required> -->
                                    <select name="member_title[1][]" class="valdtion" required>
                                      <option value="">Salutation</option>
                                      <option value="Sri">Sri</option>
                                      <option value="Smt.">Smt.</option>
                                      <option value="Mr.">Mr.</option>
                                      <option value="Mrs.">Mrs.</option>
                                      <option value="Prof.">Prof.</option>
                                      <option value="Major">Major</option>
                                      <option value="Dr.">Dr.</option> 
                                      <option value="Others">Others</option>     
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <input type="text" name="first_name[1][]" class="valdtion"  placeholder="Name" required>
                                  </div>
                                  <div class="form-group">
                                    <input type="text" name="last_name[1][]" class="valdtion"  placeholder="Surname" required>
                                  </div>
                               </div>
                            </div>
                            <a href="javascript:void(0);" class="nomieepls-a add_mem_name"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                        </div>

                         <span class="append_mem_name"></span>

                         <div class="formdiv">
                            <span class="filed_name">Father Name</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="father_name[1][]" class="valdtion"  placeholder="Father Name" required>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv nomieni-frmdiv">
                            <span class="filed_name">Nominee Name</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="nominee[1][]" class="valdtion"  placeholder="Nominee Name" required>
                               </div>
                               <a href="javascript:void(0);" class="nomieepls-a add_nominee"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                            </div>
                         </div>

                         <span class="append_nominee"></span>

                         <div class="formdiv">
                            <span class="filed_name">Type of Member </span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <select name="type_of_member[1][]" class="valdtion" required>
                                    <option>Select Type of Member</option>
                                    <option value="1">ALLOTEE</option>
                                    <option value="2">TRANSFEREE</option>
                                    <option value="3">NOMINEE</option>
                                  </select>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Date of Registration </span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="date" name="date_of_reg[1][]" class=""  placeholder="Date of Registration">
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Being No</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="being_no[1][]" class=""  placeholder="Being No">
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Membership Date</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="date" name="membership_date[1][]" class=""  placeholder="Membership Date">
                               </div>
                            </div>
                         </div>

                         

                         <div class="formdiv">
                            <span class="filed_name">Membership No.</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="membership_no[1][]" class="valdtion"  placeholder="Membership No" required>
                               </div>
                            </div>
                         </div>
                  </div>

                  <div class="plot-frm-holder plot-hlder2">
                        <div class="tooltip-holder">
                          <span>
                            <i class="fa fa-info-circle" aria-hidden="true"></i>
                          </span>

                          <div class="toltip-cntnt">
                             Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                          </div>
                        </div>
                        <div class="formdiv">
                            <span class="filed_name">Plot</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="plot" class="valdtion"  placeholder="Plot" required>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Share</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="share" class="valdtion"  placeholder="Share" required>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            
                            <span class="filed_name">Holding Name</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="holding_no" class="valdtion"  placeholder="Holding Name" required>
                               </div>
                              
                            </div>
                         </div>

                         <div class="formdiv nomieni-frmdiv dag_div">
                            <span class="filed_name">Plot Area</span>
                            <div class="frmholder">
                               <div class="form-inline">
                                <div class="form-group">
                                    <input type="text" name="kotta" placeholder="KOTTA">
                                 </div>

                                 <div class="form-group">
                                    <input type="text" name="area" placeholder="Area">
                                 </div>                                
                               </div>
                               
                            </div>
                         </div>

                         <div class="formdiv nomieni-frmdiv dag_div">
                            <span class="filed_name">Dag</span>
                            <div class="frmholder">
                               <div class="form-inline">
                                <div class="form-group">
                                    <input type="number" name="dag_sl_no[]" class="valdtion"  placeholder="Dag SL. No." required>
                                 </div>

                                 <div class="form-group">
                                    <input type="text" name="dag_no[]" class="valdtion"  placeholder="Dag Number" required>
                                 </div>                                
                               </div>
                               <a href="javascript:void(0);" class="nomieepls-a add_dag"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                            </div>
                         </div>

                         <span class="append_dag"></span>
                  </div>

                  <div class="formdiv">
                            
                        <span class="filed_name"></span>
                        <div class="frmholder">
                           <div class="form-group">
                              <input type="submit" name="submit" class=""  placeholder="" class="plot-submit">
                           </div>
                          
                        </div>
                  </div>

                </div>
            </section>

            <a class="btn btn-outline-primary" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=wp-plot-manage">Back to List</a>
          </form>

        </main>
    
    </div>

    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/jquery-3.3.1.min.js"></script> 
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/owl.carousel.min.js"></script>  
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/easy-responsive-tabs.js"></script> 
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/custom.js"></script>
</body>
</html> 