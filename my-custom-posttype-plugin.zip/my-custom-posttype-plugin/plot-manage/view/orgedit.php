<?php
session_start();
global $wpdb;
if($_POST['submit']){
   
  // echo "<pre>";
  // print_r($_REQUEST);
  // echo "</pre>";

  $plot_id = $_POST['plot_id'];

  $no_of_box = count($_POST['no_of_box']);

  $plot_table = $wpdb->prefix.'plot';   

  $data = [ 'plot' => $_POST['plot'], 'share' => $_POST['share'], 'holding_no' => $_POST['holding_no'], 'kotta' => $_POST['kotta'], 'area' => $_POST['area'], 'no_of_box' => $no_of_box ]; 

  $format = [ '%s','%s','%s','%s','%s','%d' ];  

  $where = [ 'id' =>$_POST['plot_id'] ]; 

  $plot_in = $wpdb->update( $plot_table, $data, $where ); 


  // Plot Dag Insert 

  $dag_table = $wpdb->prefix.'plot_dag';

  $wpdb->delete( $dag_table, array( 'plot_id' => $plot_id ) );

  $total_dag = count($_POST['dag_sl_no']);

  for ($dag_loop = 0; $dag_loop < $total_dag; $dag_loop++) { 

    $dag_data = array('plot_id' => $plot_id, 'dag_sl_no' => $_POST['dag_sl_no'][$dag_loop], 'dag_no' => $_POST['dag_no'][$dag_loop]);

    $dag_format = array('%d','%s','%s');

    $dag_in = $wpdb->insert($dag_table,$dag_data,$dag_format);
  }


  // Member Detail Insert

  $mem_table = $wpdb->prefix.'plot_member_details';

  $nomi_table = $wpdb->prefix.'plot_member_nominees'; 

  $wpdb->delete( $mem_table, array( 'plot_id' => $plot_id ) );

  $wpdb->delete( $nomi_table, array( 'plot_id' => $plot_id ) );

  // $password = md5('123456');

  for ($box_loop = 0; $box_loop < $no_of_box; $box_loop++) {

    $box_index = $_POST['no_of_box'][$box_loop]; 

    $count_member_name = count($_POST['member_title'][$box_index]); 

    for ($mem_loop = 0; $mem_loop < $count_member_name; $mem_loop++) {

      // $len = strlen($_POST['membership_no'][$box_index][0]);

      // if($len == 1){
      //   $login_id = 'N-000'.$_POST['membership_no'][$box_index][0];
      // }elseif ($len == 2) {
      //   $login_id = 'N-00'.$_POST['membership_no'][$box_index][0];
      // }elseif ($len == 3) {
      //   $login_id = 'N-0'.$_POST['membership_no'][$box_index][0];
      // }else {
      //   $login_id = 'N-'.$_POST['membership_no'][$box_index][0];
      // }

      

      $mem_data = array('plot_id' => $plot_id, 'box_id' => $box_index, 'member_title' => $_POST['member_title'][$box_index][$mem_loop], 'first_name' => $_POST['first_name'][$box_index][$mem_loop], 'last_name' => $_POST['last_name'][$box_index][$mem_loop], 'father_name' => $_POST['father_name'][$box_index][0], 'type_of_member' => $_POST['type_of_member'][$box_index][0], 'date_of_reg' => $_POST['date_of_reg'][$box_index][0], 'being_no' => $_POST['being_no'][$box_index][0], 'membership_date' => $_POST['membership_date'][$box_index][0], 'membership_no' => $_POST['membership_no'][$box_index][0]);

      $mem_format = array('%d','%d','%s','%s','%s','%s','%d','%s','%s','%s','%s');

      $mem_in = $wpdb->insert($mem_table,$mem_data,$mem_format);

    }

    // Nominee Insert

    $count_nominee = count($_POST['nominee'][$box_index]);     

    for ($nomi_loop = 0; $nomi_loop < $count_nominee; $nomi_loop++) {

      $nomi_data = array('plot_id' => $plot_id, 'box_id' => $box_index, 'nominee' => $_POST['nominee'][$box_index][$nomi_loop]);

      $nomi_format = array('%d','%d','%s');

      $nomi_in = $wpdb->insert($nomi_table,$nomi_data,$nomi_format);
    }

  }

  if($plot_in == 1 && $dag_in == 1 && $mem_in == 1 && $nomi_in == 1){

    $msg = "Plot Update Successfull.";

  }
  
}

// Fetch Plot Details
$plot_id = $_GET['id'];

$plot_details = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot where `id` = ".$plot_id, ""), ARRAY_A);

$no_of_box = $plot_details[0]['no_of_box'];

// Fetch Plot Dag Details

$plot_dag_details = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot_dag where `plot_id` = ".$plot_id, ""), ARRAY_A);



?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Plot</title>
    <meta name="viewport" content="width=device-width">
    <link rel="shortcut icon" type="image/x-icon" href="images/fav.png">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/easy-responsive-tabs.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/style.css">
</head>
<body>
    <div class="wrapper">
        
        <main class="site-main inner-main"> 

          <form action="" method="POST">
            <section class="plot-sec">
                <div class="container">
                  <div class="plot-heading-hlder">
                    <h2>Edit Plot</h2>
                  </div>

                  <span class="msg"><?php echo $msg; ?></span>

                  <span class="append_mem_det"></span>

                  <?php 

                    $box_ids = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT `box_id` from wp_plot_member_details where (`plot_id` = '". $plot_id ."')", ""), ARRAY_A);

                    //for($loop = $no_of_box; $loop >= 1; $loop--){ 

                    foreach ($box_ids as $key => $value) {

                    $loop = $box_ids[$key]['box_id'];

                    // Fetch Plot Member Details

                    $plot_mem_details = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot_member_details where (`plot_id` = '". $plot_id ."' AND `box_id` = '". $loop ."')", ""), ARRAY_A);

                    // Fetch Plot Nominee Details
                    $plot_nomi_details = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot_member_nominees where (`plot_id` = '". $plot_id ."' AND `box_id` = '". $loop ."')", ""), ARRAY_A);
                    
                    $box_mem_details = [];
                    $box_mem_names = [];                    
                    foreach ($plot_mem_details as $pm_details) {

                      $box_mem_names[] = array('id' => $pm_details['id'], 'member_title' => $pm_details['member_title'], 'first_name' => $pm_details['first_name'], 'last_name' =>$pm_details['last_name']);

                      $box_mem_details = array('father_name' => $pm_details['father_name'], 'type_of_member' => $pm_details['type_of_member'], 'date_of_reg' =>$pm_details['date_of_reg'], 'being_no' =>$pm_details['being_no'], 'membership_date' =>$pm_details['membership_date'], 'membership_no' =>$pm_details['membership_no']);
                      
                    }

                    echo "<pre>";
                    //print_r($plot_nomi_details);
                    echo "</pre>";
                      
                  ?>

                  <div class="plot-frm-holder ap_mem_det_div">
                      <?php if($loop == 1){ ?>
                        <a href="javascript:void(0)" class="plot-repet-a mem_details_add"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                      <?php }else{ ?>
                        <a href="javascript:void(0)" class="plot-repet-a mem_details_remove"><i class="fa fa-minus-circle" aria-hidden="true"></i></a>
                      <?php } ?>
                      <?php if($loop == 1){ ?>
                        <div class="tooltip-holder">
                          <span>
                            <i class="fa fa-info-circle" aria-hidden="true"></i>
                          </span>

                          <div class="toltip-cntnt">
                             Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                          </div>
                        </div>
                      <?php } ?>

                        <input type="hidden" name="no_of_box[]" class="no_of_box" value="<?php echo $loop; ?>">

                        <?php  
                          $mem_name_con = 1;
                          //print_r($box_mem_names);
                          foreach ($box_mem_names as $box_mem_name) {
                        ?>

                        <div class="formdiv nomieni-frmdiv <?php if($nomi_con != 1){ ?>ap_mem_div <?php } ?>">
                            <span class="filed_name"><?php if($mem_name_con == 1){ ?>Member Name<?php } ?></span>
                            <input type="hidden" name="mem_id[<?php echo $loop; ?>][]" value="<?php echo $box_mem_name['id']; ?>">
                            <div class="frmholder">
                               <div class="form-inline mem_name">
                                  <div class="form-group">
                                    <select name="member_title[<?php echo $loop; ?>][]" class="valdtion" required>
                                      <option value="">Salutation</option>
                                      <option value="SHRI" <?php if($box_mem_name['member_title'] == 'SHRI') {echo 'selected';} ?>>SHRI</option>
                                      <option value="SRI" <?php if($box_mem_name['member_title'] == 'SRI') {echo 'selected';} ?>>SRI</option>
                                      <option value="SMT." <?php if($box_mem_name['member_title'] == 'SMT.') {echo 'selected';} ?>>SMT.</option>
                                      <option value="SMT" <?php if($box_mem_name['member_title'] == 'SMT') {echo 'selected';} ?>>SMT</option>
                                      <option value="Major" <?php if($box_mem_name['member_title'] == 'Major') {echo 'selected';} ?>>Major</option>
                                      <option value="DR" <?php if($box_mem_name['member_title'] == 'DR') {echo 'selected';} ?>>DR</option>      
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <input type="text" name="first_name[<?php echo $loop; ?>][]" value="<?php echo $box_mem_name['first_name']; ?>" class="valdtion"  placeholder="Name" required>
                                  </div>
                                  <div class="form-group">
                                    <input type="text" name="last_name[<?php echo $loop; ?>][]" value="<?php echo $box_mem_name['last_name']; ?>" class="valdtion"  placeholder="Surname" required>
                                  </div>
                               </div>
                            </div>
                            <?php if($mem_name_con == 1){ ?>
                            <a href="javascript:void(0);" class="nomieepls-a add_mem_name"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                            <?php }else{ ?>
                            <a href="javascript:void(0);" class="nomieepls-a remove_mem_name"><i class="fa fa-minus-circle" aria-hidden="true"></i></a>
                            <?php } ?>
                        </div>

                        <?php $mem_name_con++; } ?>

                        <span class="append_mem_name"></span>

                         <div class="formdiv">
                            <span class="filed_name">Father Name</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="father_name[<?php echo $loop; ?>][]" value="<?php echo $box_mem_details['father_name']; ?>" value="<?php echo $box_mem_details['father_name']; ?>" class="valdtion"  placeholder="Father Name" required>
                               </div>
                            </div>
                         </div>

                        <?php  
                          $nomi_con = 1;
                          foreach ($plot_nomi_details as $plot_nomi_detail) {
                        ?>

                         <input type="hidden" name="nominee_id[<?php echo $loop; ?>][]" value="<?php echo $plot_nomi_detail['id']; ?>">

                         <div class="formdiv nomieni-frmdiv">
                            <span class="filed_name"><?php if($nomi_con == 1){ ?>Nominee Name <?php } ?></span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="nominee[<?php echo $loop; ?>][]" value="<?php echo $plot_nomi_detail['nominee']; ?>" class="valdtion"  placeholder="Nominee Name" required>
                               </div>
                               
                               <?php if($nomi_con == 1){ ?>
                                <a href="javascript:void(0);" class="nomieepls-a add_nominee"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                                <?php }else{ ?>
                                <a href="javascript:void(0);" class="nomieepls-a remove_nominee"><i class="fa fa-minus-circle" aria-hidden="true"></i></a>
                                <?php } ?>
                            </div>
                         </div>

                        <?php $nomi_con++; } ?>

                         <span class="append_nominee"></span>

                         <div class="formdiv">
                            <span class="filed_name">Type of Member </span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <select name="type_of_member[<?php echo $loop; ?>][]" class="valdtion" required>
                                    <option>Select Type of Member</option>
                                    <option value="1" <?php if($box_mem_details['type_of_member'] == 1) {echo 'selected';} ?>>ALLOTEE</option>
                                    <option value="2" <?php if($box_mem_details['type_of_member'] == 2) {echo 'selected';} ?>>TRANSFEREE</option>
                                    <option value="3" <?php if($box_mem_details['type_of_member'] == 3) {echo 'selected';} ?>>NOMINEE</option>
                                  </select>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Date of Registration </span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="date" name="date_of_reg[<?php echo $loop; ?>][]" value="<?php echo $box_mem_details['date_of_reg']; ?>" class=""  placeholder="Date of Registration">
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Being No</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="being_no[<?php echo $loop; ?>][]" value="<?php echo $box_mem_details['being_no']; ?>" class=""  placeholder="Being No">
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Membership Date</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="date" name="membership_date[<?php echo $loop; ?>][]" value="<?php echo $box_mem_details['membership_date']; ?>" class=""  placeholder="Membership Date">
                               </div>
                            </div>
                         </div>                         

                         <div class="formdiv">
                            <span class="filed_name">Membership No.</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="membership_no[<?php echo $loop; ?>][]" value="<?php echo $box_mem_details['membership_no']; ?>" class="valdtion"  placeholder="Membership No" required>
                               </div>
                            </div>
                         </div>
                  </div>

                  <?php } ?>

                  <div class="plot-frm-holder plot-hlder2">
                        <div class="tooltip-holder">
                          <span>
                            <i class="fa fa-info-circle" aria-hidden="true"></i>
                          </span>

                          <div class="toltip-cntnt">
                             Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                          </div>
                        </div>

                        <input type="hidden" name="plot_id" value="<?php echo $plot_details[0]['id']; ?>">

                        <div class="formdiv">
                            <span class="filed_name">Plot</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="plot" value="<?php echo $plot_details[0]['plot']; ?>" class="valdtion"  placeholder="Plot" required>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            <span class="filed_name">Share</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="share" value="<?php echo $plot_details[0]['share']; ?>" class="valdtion"  placeholder="Share" required>
                               </div>
                            </div>
                         </div>

                         <div class="formdiv">
                            
                            <span class="filed_name">Holding Name</span>
                            <div class="frmholder">
                               <div class="form-group">
                                  <input type="text" name="holding_no" value="<?php echo $plot_details[0]['holding_no']; ?>" class="valdtion"  placeholder="Holding Name" required>
                               </div>
                              
                            </div>
                         </div>

                         <div class="formdiv nomieni-frmdiv dag_div">
                            <span class="filed_name">Plot Area</span>
                            <div class="frmholder">
                               <div class="form-inline">
                                <div class="form-group">
                                    <input type="text" name="kotta" value="<?php echo $plot_details[0]['kotta']; ?>" placeholder="KOTTA">
                                 </div>

                                 <div class="form-group">
                                    <input type="text" name="area" value="<?php echo $plot_details[0]['area']; ?>" placeholder="Area">
                                 </div>                                
                               </div>
                               
                            </div>
                         </div>

                         <?php
                          $dag_con = 1;
                          foreach($plot_dag_details as $dag_data){
                         ?>
                         <div class="formdiv nomieni-frmdiv dag_div">
                            <span class="filed_name"><?php if($dag_con == 1){ ?>Dag<?php } ?></span>

                            <input type="hidden" name="dag_id" value="<?php echo $dag_data['id']; ?>">

                            <div class="frmholder">
                               <div class="form-inline">
                                <div class="form-group">
                                    <input type="number" name="dag_sl_no[]" value="<?php echo $dag_data['dag_sl_no']; ?>" class="valdtion"  placeholder="Dag SL. No." required>
                                 </div>

                                 <div class="form-group">
                                    <input type="text" name="dag_no[]" value="<?php echo $dag_data['dag_no']; ?>" class="valdtion"  placeholder="Dag Number" required>
                                 </div>                                
                               </div>
                               <?php if($dag_con == 1){ ?>
                               <a href="javascript:void(0);" class="nomieepls-a add_dag"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                               <?php }else{ ?>
                               <a href="javascript:void(0);" class="nomieepls-a remove_dag"><i class="fa fa-minus-circle" aria-hidden="true"></i></a>
                               <?php } ?>
                            </div>
                         </div>

                         <?php $dag_con++; } ?>

                         <span class="append_dag"></span>
                  </div>

                  <div class="formdiv">
                            
                        <span class="filed_name"></span>
                        <div class="frmholder">
                           <div class="form-group">
                              <input type="submit" name="submit" class="" value="Update" placeholder="" class="plot-submit">
                           </div>
                          
                        </div>
                  </div>

                </div>
            </section>
            <a class="btn btn-outline-primary" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=wp-plot-manage">Back to List</a>
          </form>
          
        </main>
    
    </div>

    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/jquery-3.3.1.min.js"></script> 
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/owl.carousel.min.js"></script>  
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/easy-responsive-tabs.js"></script> 
    <script src="<?php echo plugins_url('/plot-manage/view/'); ?>js/custom.js"></script>
</body>
</html> 