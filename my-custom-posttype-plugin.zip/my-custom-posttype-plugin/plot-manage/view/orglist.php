<?php

// ob_start();

global $wpdb;



if (!empty($_POST['search'])) {

    $search = $_POST['search'];

    $show_all = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot where `plot` LIKE %s", '%' .$search. '%', ""), ARRAY_A);

}else{

   $show_all = $wpdb->get_results($wpdb->prepare("SELECT * from wp_plot", ""), ARRAY_A); 

}


if (!empty($_GET['action']) && $_GET['action'] == "delete") {

    $wpdb->delete( $wpdb->prefix.'plot', array( 'id' => $_GET['id'] ) );

    $wpdb->delete( $wpdb->prefix.'plot_dag', array( 'plot_id' => $_GET['id'] ) );

    $wpdb->delete( $wpdb->prefix.'plot_member_details', array( 'plot_id' => $_GET['id'] ) );

    $wpdb->delete( $wpdb->prefix.'plot_member_nominees', array( 'plot_id' => $_GET['id'] ) );

?>

    <script>

        location.href = "<?php echo site_url() ?>/wp-admin/admin.php?page=wp-plot-manage";

    </script>

<?php

} 


?>




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  

<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />

<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('/plot-manage/view/'); ?>css/list-style.css">



<div class="vistani">

<h4>Plots List</h4>

<!-- Filter Section -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"> 

</script> 

<script src= "//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"> 

</script>



<script>

    $(document).ready(function() {

        $('#export').click(function() {

            $("#payment_data").table2excel({

                exclude: ".noExport",

                filename: "payment-data",

            });

        });

        
        $('#payment_data').DataTable(); 

    });

</script>


    <div class="table-responsive">

        <div class="search_div">
            <form action="admin.php?page=wp-plot-manage&action=search" method="POST">
                <div class="frmholder">
                    <div class="form-inline">
                        <div class="form-group">
                            <input type="text" name="search" value="<?php echo $_POST['search']; ?>" class="valdtion"  placeholder="Search by Plot Name">
                        </div>

                        <div class="form-group">
                            <input type="submit" name="submit" class=""  placeholder="" class="plot-submit">
                        </div>                                
                    </div>
                </div>
            </form>
        </div>

        <table cellpadding="10" border="1" id="payment_data" class="table table-striped table-bordered">
            <thead>
                <tr>

                    <th>Sr No.</th>

                    <th>Plot</th>

                    <th>Share</th>

                    <th>Holding Name</th>

                    <th>Action</th>

                </tr>
            </thead>

            <?php

                if(count($show_all)>0){

                $i=1;

                foreach($show_all as $index => $data){
            ?>
            <tr>

                <td><?php echo $i++; ?></td>

                <td><?php echo $data['plot']; ?></td>

                <td><?php echo $data['share']; ?></td>

                <td><?php echo $data['holding_no']; ?></td>

                <td>
                    <a href="admin.php?page=edit-wp-plot-manage&action=edit&id=<?php echo $data['id']; ?>"><i class="fa fa-edit" aria-hidden="true"></i></a>

                    <a href="admin.php?page=wp-plot-manage&id=<?php echo $data['id']; ?>&action=delete" onclick="return confirm('Are you sure want to delete this data?')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>

            </tr>

            <?php } }else{ ?>

            <tr><td colspan="5" style="text-align: center;">No data found</td></tr>

            <?php } ?>

        </table>

    </div>



</div>