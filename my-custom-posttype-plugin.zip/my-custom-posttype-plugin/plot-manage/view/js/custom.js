$(document).ready(function() {

  $('.mem_details_add').on('click', function(){ 

    // var getNumItems = $("input[name='no_of_box[]']").val();
    // alert(getNumItems.length);
    var a = $('input[name^="no_of_box"]').val();
    var b = 1;
    var numItems = parseInt(a,10) + parseInt(b,10);
    //alert(numItems);
    
    $('.append_mem_det').prepend('<div class="plot-frm-holder ap_mem_det_div diff_colour"><a href="javascript:void(0)" class="plot-repet-a mem_details_remove"><i class="fa fa-minus-circle" aria-hidden="true"></i></a><input type="hidden" name="no_of_box[]" class="no_of_box" value="'+numItems+'"><div class="formdiv nomieni-frmdiv "><span class="filed_name">Member Name</span><div class="frmholder"><div class="form-inline mem_name"><div class="form-group"><select name="member_title['+numItems+'][]" class="valdtion" required><option value="">Salutation</option><option value="SHRI">SHRI</option><option value="SRI">SRI</option><option value="SMT.">SMT.</option><option value="SMT">SMT</option><option value="Major">Major</option><option value="DR">DR</option></select></div><div class="form-group"><input type="text" name="first_name['+numItems+'][]" class="valdtion"  placeholder="Name" required></div><div class="form-group"><input type="text" name="last_name['+numItems+'][]" class="valdtion"  placeholder="Surname" required></div></div></div><a href="javascript:void(0);" class="nomieepls-a add_mem_name"><i class="fa fa-plus-circle" aria-hidden="true"></i></a></div><span class="append_mem_name"></span><div class="formdiv"><span class="filed_name">Father Name</span><div class="frmholder"><div class="form-group"><input type="text" name="father_name['+numItems+'][]" class="valdtion"  placeholder="Father Name" required></div></div></div><div class="formdiv nomieni-frmdiv"><span class="filed_name">Nominee Name</span><div class="frmholder"><div class="form-group"><input type="text" name="nominee['+numItems+'][]" class="valdtion"  placeholder="Nominee Name" required></div><a href="javascript:void(0);" class="nomieepls-a add_nominee"><i class="fa fa-plus-circle" aria-hidden="true"></i></a></div></div><span class="append_nominee"></span><div class="formdiv"><span class="filed_name">Type of Member </span><div class="frmholder"><div class="form-group"><select name="type_of_member['+numItems+'][]" class="valdtion" required><option>Select Type of Member</option><option value="1">ALLOTEE</option><option value="2">TRANSFEREE</option><option value="3">NOMINEE</option></select></div></div></div><div class="formdiv"><span class="filed_name">Date of Registration </span><div class="frmholder"><div class="form-group"><input type="date" name="date_of_reg['+numItems+'][]" class=""  placeholder="Date of Registration"></div></div></div><div class="formdiv"><span class="filed_name">Being No</span><div class="frmholder"><div class="form-group"><input type="text" name="being_no['+numItems+'][]" class=""  placeholder="Being No"></div></div></div><div class="formdiv"><span class="filed_name">Membership Date</span><div class="frmholder"><div class="form-group"><input type="date" name="membership_date['+numItems+'][]" class=""  placeholder="Membership Date"></div></div></div><div class="formdiv"><span class="filed_name">Membership No.</span><div class="frmholder"><div class="form-group"><input type="text" name="membership_no['+numItems+'][]" class="valdtion"  placeholder="Membership No" required></div></div></div></div>');

    $('.mem_details_remove').on('click', function(){
      $(this).closest('.ap_mem_det_div').remove();
    });


    // inner add / remove
    $('.add_mem_name').on('click', function(){

      var mem_no_of_box = $(this).closest('.ap_mem_det_div').find('.no_of_box').val();
      //alert(mem_no_of_box);

      $('.append_mem_name').append('<div class="formdiv nomieni-frmdiv ap_mem_div"><span class="filed_name"></span><div class="frmholder"><div class="form-inline mem_name"><div class="form-group"><select name="member_title['+mem_no_of_box+'][]" class="valdtion" required><option value="">Salutation</option><option value="SHRI">SHRI</option><option value="SRI">SRI</option><option value="SMT.">SMT.</option><option value="SMT">SMT</option><option value="Major">Major</option><option value="DR">DR</option></select></div><div class="form-group"><input type="text" name="first_name['+mem_no_of_box+'][]" class="valdtion"  placeholder="Name" required></div><div class="form-group"><input type="text" name="last_name['+mem_no_of_box+'][]" class="valdtion"  placeholder="Surname" required></div></div></div><a href="javascript:void(0);" class="nomieepls-a remove_mem_name"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></div>');

      $('.remove_mem_name').on('click', function(){
        $(this).closest('.ap_mem_div').remove();
      });

    });

    $('.add_nominee').on('click', function(){

      var nomi_no_of_box = $(this).closest('.ap_mem_det_div').find('.no_of_box').val();

      $('.append_nominee').append('<div class="formdiv nomieni-frmdiv"><span class="filed_name"></span><div class="frmholder"><div class="form-group"><input type="text" name="nominee['+nomi_no_of_box+'][]" class="valdtion"  placeholder="Nominee Name" required></div><a href="javascript:void(0);" class="nomieepls-a remove_nominee"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></div></div>');


      $('.remove_nominee').on('click', function(){
        $(this).closest('.nomieni-frmdiv').remove();
      });

    });


  });

  $('.mem_details_remove').on('click', function(){
    $(this).closest('.ap_mem_det_div').remove();
  });


  $('.add_mem_name').on('click', function(){
    var mem_no_of_box = $(this).closest('.ap_mem_det_div').find('.no_of_box').val();
    //alert(mem_no_of_box);
    $('.append_mem_name').append('<div class="formdiv nomieni-frmdiv ap_mem_div"><span class="filed_name"></span><div class="frmholder"><div class="form-inline mem_name"><div class="form-group"><select name="member_title['+mem_no_of_box+'][]" class="valdtion" required><option value="">Salutation</option><option value="SHRI">SHRI</option><option value="SRI">SRI</option><option value="SMT.">SMT.</option><option value="SMT">SMT</option><option value="Major">Major</option><option value="DR">DR</option></select></div><div class="form-group"><input type="text" name="first_name['+mem_no_of_box+'][]" class="valdtion"  placeholder="Name" required></div><div class="form-group"><input type="text" name="last_name['+mem_no_of_box+'][]" class="valdtion"  placeholder="Surname" required></div></div></div><a href="javascript:void(0);" class="nomieepls-a remove_mem_name"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></div>');

    $('.remove_mem_name').on('click', function(){
      $(this).closest('.ap_mem_div').remove();
    });

  });

  $('.remove_mem_name').on('click', function(){
    $(this).closest('.ap_mem_div').remove();
  });

  $('.add_nominee').on('click', function(){
    var nomi_no_of_box = $(this).closest('.ap_mem_det_div').find('.no_of_box').val();
    $('.append_nominee').append('<div class="formdiv nomieni-frmdiv"><span class="filed_name"></span><div class="frmholder"><div class="form-group"><input type="text" name="nominee['+nomi_no_of_box+'][]" class="valdtion"  placeholder="Nominee Name" required></div><a href="javascript:void(0);" class="nomieepls-a remove_nominee"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></div></div>');

    $('.remove_nominee').on('click', function(){
      $(this).closest('.nomieni-frmdiv').remove();
    });

  });

  $('.remove_nominee').on('click', function(){
    $(this).closest('.nomieni-frmdiv').remove();
  });

  $('.add_dag').on('click', function(){
    $('.append_dag').append('<div class="formdiv nomieni-frmdiv dag_div"><span class="filed_name"></span><div class="frmholder"><div class="form-inline"><div class="form-group"><input type="number" name="dag_sl_no[]" class="valdtion"  placeholder="Dag SL. No."></div><div class="form-group"><input type="text" name="dag_no[]" class="valdtion"  placeholder="Dag Number"></div></div><a href="javascript:void(0);" class="nomieepls-a remove_dag"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></div></div>');


    $('.remove_dag').on('click', function(){
      $(this).closest('.dag_div').remove();
    });

  });

  $('.remove_dag').on('click', function(){
    $(this).closest('.dag_div').remove();
  });



});

