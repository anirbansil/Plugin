<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css" integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
<div class="container">
    <h4 class="my-4">Booking Records</h4>
    <table id="myTable" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Booking Shows</th>
                <th>Payment Amount</th>
                <th>Payment Type</th>
                <th>Booking Date</th>
                <th>View</th>
            </tr>
        </thead>
        <?php global $wpdb;
        $records = 'booking_records';
        $results = $wpdb->get_results("SELECT * FROM $records"); ?>
        <tbody>
            <?php foreach ($results as $row) { ?>
            <tr>
                <td><?php echo esc_html($row->id); ?></td>
                <td><?php echo esc_html($row->pay_amount); ?></td>
                <td><?php echo esc_html($row->payment_type); ?></td>
                <td><?php echo esc_html($row->submitted_at); ?></td>
                <td><a href="admin.php?page=show-booking-record-details&action=details&id=<?php echo esc_html($row->id); ?>" class="btn btn-primary">View</a></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>