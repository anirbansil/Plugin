<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
</head>
<body>
    <h2>Show Reservation Settings</h2>

    <p>Use this shortcode for shows list [shows-list]</p>

    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">

        <?php 
        wp_nonce_field('rpp_reserved_page_action', 'rpp_reserved_page_nonce');
        
            $selected_page = get_option( 'rpp_reserved_page' );
            $pages = get_pages();
            echo '<select name="rpp_reserved_page">';
            echo '<option value="">Select a Page</option>';
            foreach ( $pages as $page ) {
                $selected = ($selected_page == $page->ID) ? 'selected="selected"' : '';
                echo '<option value="' . $page->ID . '" ' . $selected . '>' . $page->post_title . '</option>';
            }
            echo '</select>';

        ?>
        <input type="hidden" name="action" value="save_rpp_reserved_page">
        <button type="submit">Submit</button>
    </form>
</body>
</html>