<style>
    .full-width {
        width: 100%;
        box-sizing: border-box;
        padding: 8px;
        margin-bottom: 10px;
    }
    .button-primary {
        margin-top: 10px;
    }
    .file-info {
        margin-top: 10px;
    }
    .time-seat-container {
        margin-top: 10px;
    }
    .time-seat-entry {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #f9f9f9;
    }
    .time-seat-entry input {
        margin-right: 10px;
    }
    .remove-time-seat {
        cursor: pointer;
        color: red;
        margin-left: 10px;
        font-weight: bold;
    }
    .remove-time-seat:hover {
        text-decoration: underline;
    }
    .add-button {
        margin-top: 10px;
    }
    </style>
    <label for="show_sub_title"><?php _e('Sub Title', 'shows'); ?></label>
    <input type="text" class="full-width" id="show_sub_title" name="show_sub_title" value="<?php echo esc_attr($show_sub_title); ?>" />
    
    <label for="show_date"><?php _e('Date', 'shows'); ?></label>
    <input type="date" class="full-width" id="show_date" name="show_date" value="<?php echo esc_attr($show_date); ?>" />
    
    <div id="time_seat_container" class="time-seat-container">
        <label><?php _e('Times and Seat Limits', 'shows'); ?></label>
        <?php if (!empty($show_time) && is_array($show_time)):
            $count = count($show_time);
            for ($i = 0; $i < $count; $i++): ?>
                <div class="time-seat-entry">
                    <input type="time" class="full-width" name="show_time[]" value="<?php echo esc_attr($show_time[$i]); ?>" />
                    <input type="number" class="full-width" name="seat_limit[]" value="<?php echo esc_attr($seat_limit[$i]); ?>" placeholder="<?php _e('Seat Limit', 'shows'); ?>" />
                    <?php if ($i != 0) { ?>
                        <span class="remove-time-seat"><?php _e('Remove', 'shows'); ?></span>
                    <?php } ?>
                </div>
            <?php endfor; ?>
        <?php else: ?>
            <div class="time-seat-entry">
                <input type="time" class="full-width" name="show_time[]" />
                <input type="number" class="full-width" name="seat_limit[]" placeholder="<?php _e('Seat Limit', 'shows'); ?>" />
            </div>
        <?php endif; ?>
    </div>
    <button type="button" id="add_time_seat" class="button add-button"><?php _e('Add Time and Seat Limit', 'shows'); ?></button>

    <label for="show_price"><?php _e('Price', 'shows'); ?></label>
    <input type="text" class="full-width" id="show_price" name="show_price" value="<?php echo esc_attr($show_price); ?>" />
    
    <label for="show_location"><?php _e('Location', 'shows'); ?></label>
    <input type="text" class="full-width" id="show_location" name="show_location" value="<?php echo esc_attr($show_location); ?>" />
    
    <label for="study_guide"><?php _e('Upload File', 'shows'); ?></label>
    <input type="hidden" id="study_guide" name="study_guide" value="<?php echo esc_url($study_guide_url); ?>" />
    <button type="button" id="upload_button" class="button-primary"><?php _e('Upload File', 'shows'); ?></button>
    <div class="file-info">
        <?php if ($study_guide_url): ?>
            <p><a href="<?php echo esc_url($study_guide_url); ?>" target="_blank"><?php _e('View Uploaded File', 'shows'); ?></a></p>
            <p><?php echo esc_html($study_guide_name); ?></p>
        <?php else: ?>
            <p><?php _e('No file uploaded', 'shows'); ?></p>
        <?php endif; ?>
    </div>
    <script>
        document.getElementById('add_time_seat').addEventListener('click', function() {
            var container = document.getElementById('time_seat_container');
            var newEntry = document.createElement('div');
            newEntry.classList.add('time-seat-entry');
            newEntry.innerHTML = '<input type="time" class="full-width" name="show_time[]" /> <input type="number" class="full-width" name="seat_limit[]" placeholder="<?php _e('Seat Limit', 'shows'); ?>" /> <span class="remove-time-seat">Remove</span>';
            container.appendChild(newEntry);

            // Remove time-seat entry
            newEntry.querySelector('.remove-time-seat').addEventListener('click', function() {
                container.removeChild(newEntry);
            });
        });

        document.querySelectorAll('.remove-time-seat').forEach(function(button) {
            button.addEventListener('click', function() {
                var entry = button.parentNode;
                entry.parentNode.removeChild(entry);
            });
        });

        jQuery(document).ready(function($) {
            var mediaUploader;

            $('#upload_button').click(function(e) {
                e.preventDefault();
                
                // If the media uploader object already exists, reopen the dialog
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                
                // Extend the wp.media object
                mediaUploader = wp.media.frames.file_frame = wp.media({
                    title: 'Choose File',
                    button: {
                        text: 'Use this file'
                    },
                    multiple: false
                });

                // When a file is selected, grab the URL and set it as the text field's value
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#study_guide').val(attachment.url);
                    $('#upload_button').siblings('.file-info').html('<p><a href="' + attachment.url + '" target="_blank">View Uploaded File</a></p><p>' + attachment.filename + '</p>');
                });

                // Open the uploader dialog
                mediaUploader.open();
            });
        });
    </script>