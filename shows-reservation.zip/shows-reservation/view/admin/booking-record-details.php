<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css" integrity="sha512-B46MVOJpI6RBsdcU307elYeStF2JKT87SsHZfRSkjVi4/iZ3912zXi45X5/CBr/GbCyLx6M1GQtTKYRd52Jxgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
<div class="container">
    <h4 class="my-4">Show Record Booking Details</h4>
    <?php
    $recordid = intval($_GET['id']);
    global $wpdb;
    $records = 'booking_records';
    $shows = 'booking_shows';

    $shwqry = $wpdb->prepare("SELECT * FROM $shows WHERE booking_record_id = %d", $recordid);
    $showsrslts = $wpdb->get_results($shwqry);

    // Check if results are returned
    if (!empty($showsrslts)) { ?>

    <table id="myTable" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Show Name</th>
                <th>Date & Time</th>
                <th>Location</th>
                <th>Seatprice</th>
                <th>Students</th>
                <th>Teachers</th>
                <th>Para</th>
                <th>Chaperones</th>
                <th>Others</th>
                <th>Gross Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($showsrslts as $row) { ?>
            <tr>
                <td><?php echo esc_html($row->showname); ?></td>
                <td><?php echo esc_html($row->datetime); ?></td>
                <td><?php echo esc_html($row->location); ?></td>
                <td><?php echo esc_html($row->seatprice); ?></td>
                <td><?php echo esc_html($row->students); ?></td>
                <td><?php echo esc_html($row->teachers); ?></td>
                <td><?php echo esc_html($row->para); ?></td>
                <td><?php echo esc_html($row->chaperones); ?></td>
                <td><?php echo esc_html($row->others); ?></td>
                <td><?php echo esc_html($row->grosstotal); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <?php } ?>

    <table id="myTable" class="table table-striped table-bordered">
        <tbody>
            <?php // Use the prefix for custom tables
            $query = $wpdb->prepare("SELECT * FROM $records WHERE id = %d", $recordid);
            $results = $wpdb->get_results($query);

            // Check if results are returned
            if (!empty($results)) {
                foreach ($results as $row) {
                    $payment_type = esc_html($row->payment_type);
                    $pay_amount = esc_html($row->pay_amount);
                    $submitted_at = esc_html($row->submitted_at);
                    $payment_details = @unserialize($row->payment_details);
                    if ($payment_details === false && $row->payment_details !== 'b:0;') {
                        $payment_details = array(); // Handle unserialization error
                    }

                    ?>
                    <tr>
                        <th>Payment Method</th>
                        <td><?php echo $payment_type; ?></td>
                    </tr>
                    <tr>
                        <th>Pay Amount</th>
                        <td><?php echo $pay_amount; ?></td>
                    </tr>
                    <tr>
                        <th>Submit Date</th>
                        <td><?php echo $submitted_at; ?></td>
                    </tr>
                    <tr>
                        <th colspan="2" text-align: center;>Payment Details</th>
                    </tr>
                    <?php
                    // Check if payment_details is an array
                    if (is_array($payment_details)) {
                        foreach ($payment_details as $key => $value) {
                            $modifiedString = str_replace('_', ' ', $key);
                            $words = explode(' ', $modifiedString);
                            array_shift($words);
                            $resultString = implode(' ', $words);
                            $resultString = ucfirst($resultString);
                            ?>
                            <tr>
                                <th><?php echo esc_html($resultString); ?></th>
                                <td><?php echo esc_html($value); ?></td>
                            </tr>
                            <?php
                        }
                    } else {
                        // Handle the case where payment_details is not an array or unserialization failed
                        ?>
                        <tr>
                            <td colspan="2">No additional details available.</td>
                        </tr>
                        <?php
                    }
                }
            } else {
                ?>
                <tr>
                    <td colspan="2">No records found.</td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>