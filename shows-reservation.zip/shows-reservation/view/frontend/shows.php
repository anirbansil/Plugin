<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shows List</title>
    <!-- fontawesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
      
        .book-res-sec {
            padding: 60px 0;
        }
        .item-box {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
            text-align: center;
            margin: 10px 0;
            transition: transform 0.3s;
            background-color: #F4F4F4;
            height:100%;
        }
        .item-box:hover {
            transform: scale(1.05);
        }
       
    </style>
</head>
<body class="shows-body">

<section class="book-res-sec back-img">
    <div class="about-wrap sec-b-padd">
        <div class="about-right">
            <div class="about-content">
                <div class="features-tab">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="nav-all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true">All Theatres</button>
                        </li>
                        <?php $args = array(
                            'taxonomy'   => 'show_type',
                            'hide_empty' => false,
                        );
                        $terms = get_terms($args);
                        if (!empty($terms) && !is_wp_error($terms)) :
                        foreach ($terms as $term) : ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="nav-<?php echo esc_html($term->slug); ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo esc_html($term->slug); ?>" type="button" role="tab" aria-controls="<?php echo esc_html($term->slug); ?>" aria-selected="false" tabindex="-1"><?php echo esc_html($term->name); ?></button>
                        </li>
                        <?php endforeach; endif; ?>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="all" role="tabpanel" aria-labelledby="nav-all-tab">
                            <div class="section-title-border mb-3">
                                <h2>All Theatres</h2>
                            </div>
                            <!-- Grid Items in Bio Tab -->
                            <div class="row">
                                <?php $args = array(
                                    'post_type' => 'shows',
                                    'posts_per_page' => -1,
                                );
                                $query = new WP_Query($args);
                                if ($query->have_posts()) :
                                    while ($query->have_posts()) : $query->the_post();
                                    $show_sub_title = get_post_meta(get_the_ID(), '_show_sub_title', true);
                                    $show_date = get_post_meta(get_the_ID(), '_show_date', true);
                                    $show_times = get_post_meta(get_the_ID(), '_show_time', true); // Change to false to get an array
                                    $show_price = get_post_meta(get_the_ID(), '_show_price', true);
                                    $show_location = get_post_meta(get_the_ID(), '_show_location', true); ?>
                                <div class="col-md-3">
                                    <div class="item-box">
                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>">
                                        <h4><?php the_title(); ?></h4>
                                        <p><?php echo esc_html($show_sub_title); ?></p>
                                        <div class="item-dtls">
                                            <div class="showDate">
                                                <div class="calender">
                                                    <i class="fa-regular fa-calendar-days"></i>
                                                </div>
                                                <div class="date">
                                                    <p><?php echo esc_html($show_date); ?></p>
                                                </div>
                                            </div>
                                            <?php if ($show_location) { ?>
                                            <div class="location">
                                                <div class="locatnIcon">
                                                    <i class="fa-solid fa-location-dot"></i>
                                                </div>
                                                <a href="#"><?php echo esc_html($show_location); ?></a>
                                            </div>
                                        <?php } ?>
                                            <div class="price-wrap">
                                                <div class="showPrice"><i class="fa fa-ticket"></i> <span>$<?php echo esc_html($show_price); ?></span></div>
                                                <div class="showGrade"><i class="fa fa-graduation-cap"></i> <span>PK-4 </span></div>
                                            </div>
                                            <?php if (!empty($show_times) && is_array($show_times)) {
                                            foreach ($show_times as $time) { ?>
                                            <div class="showTime">
                                                <div class="time">
                                                    <i class="fa-regular fa-clock"></i><?php echo date('h:i A', strtotime($time)); ?>
                                                </div>
                                                <div class="rsrv-btn">
                                                    <a href="javascript:void(0)" class="button reserveSeats_new reserveSeats" data-showing="1" data-id="<?php echo get_the_ID(); ?>" data-date="<?php echo esc_html($show_date); ?>" data-time="<?php echo esc_html($time); ?>"><i class="fa fa-plus"></i> Reserve</a>
                                                </div>
                                            </div>
                                            <?php } } else {
                                                echo '<p>' . __('No show times available.', 'shows') . '</p>';
                                            } ?>
                                            <div class="item-btn">
                                                <a href="<?php echo esc_url(get_permalink()); ?>"><i class="fa-solid fa-circle-info"></i> View Details</a>
                                                <a href="javascript:void(0)"><i class="fa-regular fa-file-pdf"></i> Study Guide</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <?php endwhile; endif; ?>
                            </div>
                        </div>
                        <?php $args = array(
                            'taxonomy'   => 'show_type',
                            'hide_empty' => false,
                        );
                        $terms = get_terms($args);
                        if (!empty($terms) && !is_wp_error($terms)) :
                        foreach ($terms as $term) : ?>
                        <div class="tab-pane fade" id="<?php echo esc_html($term->slug); ?>" role="tabpanel" aria-labelledby="nav-<?php echo esc_html($term->slug); ?>-tab">
                            <div class="section-title-border mb-3">
                                <h2><?php echo esc_html($term->name); ?></h2>
                            </div>
                            <!-- Grid Items in Media Tab -->
                            <div class="row">
                                <?php $args = array(
                                    'post_type' => 'shows',
                                    'posts_per_page' => -1,
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'show_type',
                                            'field'    => 'slug',
                                            'terms'    => $term->slug,
                                            'operator' => 'IN',
                                        ),
                                    ),
                                );
                                $query = new WP_Query($args);
                                if ($query->have_posts()) :
                                    while ($query->have_posts()) : $query->the_post();
                                    $show_sub_title = get_post_meta(get_the_ID(), '_show_sub_title', true);
                                    $show_date = get_post_meta(get_the_ID(), '_show_date', true);
                                    $show_times = get_post_meta(get_the_ID(), '_show_time', true); // Change to false to get an array
                                    $show_price = get_post_meta(get_the_ID(), '_show_price', true);
                                    $show_location = get_post_meta(get_the_ID(), '_show_location', true); ?>
                                <div class="col-md-3">
                                    <div class="item-box">
                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>">
                                        <h4><?php the_title(); ?></h4>
                                        <p><?php echo esc_html($show_sub_title); ?></p>
                                        <div class="item-dtls">
                                            <div class="showDate">
                                                <div class="calender">
                                                    <i class="fa-regular fa-calendar-days"></i>
                                                </div>
                                                <div class="date">
                                                    <p><?php echo esc_html($show_date); ?></p>
                                                </div>
                                            </div>
                                            <?php if ($show_location) { ?>
                                            <div class="location">
                                                <div class="locatnIcon">
                                                    <i class="fa-solid fa-location-dot"></i>
                                                </div>
                                                <a href="#"><?php echo esc_html($show_location); ?></a>
                                            </div>
                                            <?php } ?>
                                            <div class="price-wrap">
                                                <div class="showPrice"><i class="fa fa-ticket"></i> <span>$<?php echo esc_html($show_price); ?></span></div>
                                                <div class="showGrade"><i class="fa fa-graduation-cap"></i> <span>PK-4 </span></div>
                                            </div>
                                            <?php if (!empty($show_times) && is_array($show_times)) {
                                            foreach ($show_times as $time) { ?>
                                            <div class="showTime">
                                                <div class="time">
                                                    <i class="fa-regular fa-clock"></i><?php echo esc_html($time); ?>
                                                </div>
                                                <div class="rsrv-btn">
                                                <a href="javascript:void(0)" class="button reserveSeats_new reserveSeats" data-showing="1" data-id="<?php echo get_the_ID(); ?>" data-date="<?php echo esc_html($show_date); ?>" data-time="<?php echo esc_html($time); ?>"><i class="fa fa-plus"></i> Reserve</a>
                                                </div>
                                            </div>
                                            <?php } } else {
                                                echo '<p>' . __('No show times available.', 'shows') . '</p>';
                                            } ?>
                                            <div class="item-btn">
                                                <a href="<?php echo esc_url(get_permalink()); ?>">View Details</a>
                                                <a href="javascript:void(0)"><i class="fa-regular fa-file-pdf"></i> Study Guide</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <?php endwhile; endif; ?>
                            </div>
                        </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Bootstrap and jQuery JS -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // JavaScript for tab functionality
    jQuery(document).ready(function($) {
        // Change the active tab on click
        $('.nav-tabs .nav-link').on('click', function() {
            $('.nav-tabs .nav-link').removeClass('active');
            $(this).addClass('active');

            $('.tab-pane').removeClass('active show');
            $($(this).data('bs-target')).addClass('active show');
        });

        
        $('.reserveSeats_new').on('click', function() {
            var showid = $(this).data('id');
            var showdate = $(this).data('date');
            var showtime = $(this).data('time');

            // Check if values are retrieved correctly
            // alert('ID: ' + showid);
            // alert('Date: ' + showdate);
            // alert('Time: ' + showtime);

            var data = {
                action: 'fcp_redirect_item', // This is the action we hooked into in PHP                  
                showid: showid,
                showdate: showdate,
                showtime: showtime,
            };

            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // Use localized AJAX URL
                // data: JSON.stringify({
                //     action: 'fcp_redirect_item',
                //     showid: showid,
                //     showdate: showdate,
                //     showtime: showtime,
                //     nonce: '<?php echo wp_create_nonce('item_nonce'); ?>'
                // }),
                data:data,
                success: function(data) {
                    if (data.redirect_url) {
                        window.location.href = data.redirect_url; // Redirect to the specified URL
                    } else {
                        console.log(data.message); // Show error message
                    }
                }
            });
        });
    });
</script>
 
</body>
</html>
