
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shows details</title>
    <!-- fontawesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" id="your-plugin-style-css" href="https://elvirainfotech.online/shows-reservation/wp-content/plugins/shows-reservation/assets/style.css?ver=6.6.1" media="all">
</head>
<body class="shows-details-page">
<section class="shows-details">
 <?php
  if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
  }

  if (have_posts()) : 
    while (have_posts()) : the_post(); 
        // Get meta values
        $show_sub_title = get_post_meta(get_the_ID(), '_show_sub_title', true);
        $show_date = get_post_meta(get_the_ID(), '_show_date', true);
        $show_times = get_post_meta(get_the_ID(), '_show_time', true);
        $show_price = get_post_meta(get_the_ID(), '_show_price', true);
        $show_location = get_post_meta(get_the_ID(), '_show_location', true);
        ?>
        
        <div class="container">
            <div class="row">
               <div class="col-md-6">
                 <div class="thmubnail-img">
                <?php 
                if (has_post_thumbnail()) {
                    the_post_thumbnail('large'); // Display the featured image
                } 
                ?>
                 </div>
               </div>
               <div class="col-md-6">
                 <div class="shows-dtls">
                    <h1><?php the_title(); ?></h1>
                    <h2><?php echo esc_html($show_sub_title); ?></h2>
                    <ul class="dtls-time">
                        <li><strong>Date:</strong> <?php echo esc_html($show_date); ?></li>
                        <li>
                        <?php if (!empty($show_times) && is_array($show_times)) {
                            foreach ($show_times as $time) { ?>
                            <div class="showTime">
                             <strong>Time:</strong>
                                <div class="time">
                                    <i class="fa-regular fa-clock"></i><?php echo date('h:i A', strtotime($time)); ?>
                                </div>
                                <div class="rsrv-btn">
                                    <a href="javascript:void(0)" class="button reserveSeats_new reserveSeats" data-showing="1" data-id="<?php echo get_the_ID(); ?>" data-date="<?php echo esc_html($show_date); ?>" data-time="<?php echo esc_html($time); ?>"><i class="fa fa-plus"></i> Reserve</a>
                                 </div>
                            </div>

                        <?php } } else {
                            echo '<p>' . __('No show times available.', 'shows') . '</p>';
                        } ?>
                        </li>

                        <li><strong>Price/Seat:</strong> <?php echo esc_html($show_price); ?></li>
                        <?php if ($show_location) { ?>
                        <li><strong>Location:</strong> <?php echo esc_html($show_location); ?></li>
                        <?php } ?>
                    </ul>
                    <!-- <div class="registr_btn">
                    <a href="<?php echo esc_url(home_url('/reserve')); ?>">
                    Register for this Show
                    </a>
                    </div> -->
                 </div>
               </div>
                <div class="col-md-12">
                  <div class="show-description">
                   <?php the_content(); // Display the content of the post ?>
                   </div>
                </div>
              </div>

          </div>

        <?php
    endwhile;
else : 
    echo '<p>' . __('No shows found.', 'shows') . '</p>';
 endif;

 ?>
</section>



<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // JavaScript for tab functionality
jQuery(document).ready(function($) {
    
    $('.reserveSeats_new').on('click', function() {
        var showid = $(this).data('id');
        var showdate = $(this).data('date');
        var showtime = $(this).data('time');

            // alert('ID: ' + showid);
            // alert('Date: ' + showdate);
            // alert('Time: ' + showtime);

        var data = {
            action: 'fcp_redirect_item', // This is the action we hooked into in PHP                  
            showid: showid,
            showdate: showdate,
            showtime: showtime,
        };

        $.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>', // Use localized AJAX URL

            data:data,
            success: function(data) {
                if (data.redirect_url) {
                    window.location.href = data.redirect_url; // Redirect to the specified URL
                } else {
                    console.log(data.message); // Show error message
                }
            }
        });
    });
});
</script>
</body>
</html>


