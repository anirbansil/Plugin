<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Reservation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel='stylesheet' href='https://shows-reservation.elvirainfotech.live/wp-content/plugins/shows-reservation/assets/style.css?ver=6.6.1' media='all' />
</head>
<body>

<div class="container">
    <div class="contact-wrap">
        <div class="contact-form-head">
        <h2>Reservation Form</h2>
        </div>
   
        <form id="reserveform">
            <div class="mb-4 bookingsec">
                <h4>Booking Shows</h4>
                <?php if(!class_exists('Session')){
                    require_once show_reservation_base_path ."sessions-master/database.class.php";  //Include MySQL database class
                    // die();
                    require_once show_reservation_base_path ."sessions-master/mysql.sessions.php";  //Include PHP MySQL sessions
                    // Ensure session is started
                    $session = new Session();
                } ?>
                <div id="bookingshows">
                    <?php if (isset($_SESSION['show_details_data']) && is_array($_SESSION['show_details_data'])) {
                    // Loop through each item in the session array
                    foreach ($_SESSION['show_details_data'] as $show_details) {
                    $show_id = isset($show_details['show_id']) ? $show_details['show_id'] : 'N/A';
                    $show_date = isset($show_details['show_date']) ? $show_details['show_date'] : 'N/A';
                    $show_time = isset($show_details['show_time']) ? $show_details['show_time'] : 'N/A';
                    $location = get_post_meta($show_id, '_show_location', true);
                    $show_price = get_post_meta($show_id, '_show_price', true); ?>
                    <div class="booking-row">
                        <div class="headbar row">
                            <div class="title col-md-11">
                                <h6>Show Details</h6>
                            </div>
                            <div class="close col-md-1">
                                <button type="button" class="btn btn-danger remove-row" data-id="<?php echo $show_id; ?>" data-date="<?php echo $show_date; ?>" data-time="<?php echo $show_time; ?>">Remove</button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-4">
                                <label for="phoneLabel">Show Name</label>
                                <input type="text" name="showname[]" class="form-control" value="<?php echo get_the_title( $show_id ); ?>" placeholder="Show Name" >
                                <input type="hidden" name="showid[]" value="<?php echo $show_id; ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="label">Date & Time</label>
                                <input type="text" name="datetime[]" class="form-control" value="<?php echo $show_date; ?> - <?php echo $show_time; ?>" placeholder="Date & Time" >
                            </div>
                            <div class="col-md-4">
                                <label for="label">Location</label>
                                <input type="text" name="location[]" class="form-control" value="<?php echo $location; ?>" placeholder="Location" >
                            </div>
                            <div class="col-md-1">
                                <label for="label">Price/Seat</label>
                                <span class="seatprice">$<?php echo $show_price; ?></span>
                                <input type="hidden" name="seatprice[]" value="<?php echo $show_price; ?>">
                            </div>
                        </div>
                        <div class="form-group row form-secnd-row">
                            <div class="col-md-1">
                                <label>&nbsp;</label>
                                <input type="text" name="grade[]" class="form-control" value="Grade"  readonly>
                            </div>
                            <div class="col-md-2">
                                <label for="label">Students</label>
                                <input type="number" name="students[]" class="form-control seatbook" data-seatper="<?php echo $show_price; ?>" placeholder="0" >
                            </div>
                            <div class="col-md-2">
                                <label for="label">Teachers Free</label>
                                <input type="number" name="teachers[]" class="form-control seatbook" data-seatper="<?php echo $show_price; ?>" placeholder="0" >
                            </div>
                            <div class="col-md-2">
                                <label for="label">Para</label>
                                <input type="number" name="para[]" class="form-control seatbook" data-seatper="<?php echo $show_price; ?>" placeholder="0" >
                            </div>
                            <div class="col-md-2">
                                <label for="label">Chaperones</label>
                                <input type="number" name="chaperones[]" class="form-control seatbook" data-seatper="<?php echo $show_price; ?>" placeholder="0" >
                            </div>
                            <div class="col-md-2">
                                <label for="label">Others</label>
                                <input type="number" name="others[]" class="form-control seatbook" data-seatper="<?php echo $show_price; ?>" placeholder="0" >
                            </div>
                            <div class="col-md-1">
                                <label>Total</label>
                                <span class="grosstotal"></span>
                                <input type="hidden" name="grosstotal[]" value="">
                            </div>
                        </div>
                    </div>
                    <?php } } ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="total-wrap">
                            <label>Total</label>
                            <span class="nettotal"></span>
                            <input type="hidden" class="netamt" name="nettotal" value="">
                        </div>
                    </div>
                </div>
                <a href="https://elvirainfotech.online/shows-reservation/" class="btn btn-primary" id="addshow">Add Show</a>
                <a href="#" class="btn btn-primary" id="addshow">Update</a>
                <a href="https://elvirainfotech.online/shows-reservation/reserve/" class="btn btn-primary" id="addshow">Clear</a>
            </div>

            <!-- Personal Information Section -->
            <div class="mb-4 billingsec">
                <h4>How would you like to be billed?</h4>
                <fieldset class="form-group">
                    <div class="form-radio">
                        <input class="form-radio-input sendinvoice" type="radio" name="communication" data-type="sendinvoice" value="send invoice"  checked>
                        <span class="checkmark"></span>
                        <label class="form-check-label" for="sendinvoice">Send Invoice to my school</label>
                    </div>
                    <div class="form-radio">
                        <input class="form-radio-input purchaseorder" type="radio" name="communication" data-type="purchaseorder" value="purchase order" >
                        <span class="checkmark"></span>
                        <label class="form-check-label" for="purchaseorder">I will pay by Purchase Order</label>
                    </div>
                    <div class="form-radio">
                        <input class="form-radio-input echeck" type="radio" name="communication" data-type="echeck" value="e-check" >
                        <span class="checkmark"></span>
                        <label class="form-check-label" for="echeck">I will pay by personal E-CHECK</label>
                    </div>
                    <div class="form-radio">
                        <input class="form-radio-input creditcard" type="radio" name="communication" data-type="creditcard" value="credit card" >
                        <span class="checkmark"></span>
                        <label class="form-check-label" for="creditcard">I will pay by credit card</label>
                    </div>
                </fieldset>
                <div class="form-group check-box-list sendinvoice-chks">
                    <div class="form-check">
                        <input class="form-check-input" name="invoice_policy_one" type="checkbox" id="newsletter" value="I understand that payment in full must be received by the date specified on the invoice.">
                        <label class="form-check-label" for="newsletter">I understand that payment in full must be received by the date specified on the invoice.</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" name="invoice_policy_two" type="checkbox" id="newsletter" value="Paid in Full Invoice serves as your tickets to enter the theater">
                        <label class="form-check-label" for="newsletter">Paid in Full Invoice serves as your tickets to enter the theater</label>
                    </div>
                </div>
                <div class="form-group check-box-list purchaseorder-chks">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="purchase_policy_one" id="newsletter" value="Purchase Order Must be Paid by the date specified on the invoice.">
                        <label class="form-check-label" for="newsletter">Purchase Order Must be Paid by the date specified on the invoice.</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="purchase_policy_two" id="newsletter" value="Paid in Full Purchase Order serves as your tickets to enter the theater.">
                        <label class="form-check-label" for="newsletter">Paid in Full Purchase Order serves as your tickets to enter the theater.</label>
                    </div>
                </div>
                <div class="form-group check-box-list echeck-chks">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="echeck_policy_one" id="newsletter" value="yes">
                        <label class="form-check-label" for="newsletter">ONLY Teachers Checks Accepted. Parents Checks are Not Accepted.</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="echeck_policy_two" id="newsletter" value="yes">
                        <label class="form-check-label" for="newsletter">I will call office 718-266-0202 to pay E-CHECK by phone (Free of Charge).
                        Routine & Account number needed to process transaction by phone.</label>
                    </div>
                </div>
                <div class="form-group check-box-list creditcard-chks">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="creditcard_policy_one" id="newsletter" value="yes">
                        <label class="form-check-label" for="newsletter">I will call office 718-266-0202 to pay by credit card by phone (convenient 3,5% fee applies).</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="creditcard_policy_two" id="newsletter" value="yes">
                        <label class="form-check-label" for="newsletter">I give my full permission to charge my credit card (convenient 3,5% fee applies).
                        I understand All Sales are Final. No Refund or Credits.</label>
                    </div>
                </div>
            </div>
            <div class="mb-4 allfields sendinvoice-allfields">
                <h4>School and Contact Information</h4>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="teacher">Teacher/Principal/AP/Administrator (Title)</label>
                        <input type="text" name="invoice_teacher" class="form-control" id="teacher" placeholder="Teacher/Principal/AP/Administrator (Title)" >
                    </div>
                    <div class="col-md-4">
                        <label for="firstName">First Name</label>
                        <input type="text" name="invoice_firstname" class="form-control" id="firstName" placeholder="Enter your first name" >
                    </div>
                    <div class="col-md-4">
                        <label for="lastName">Last Name</label>
                        <input type="text" name="invoice_lastname" class="form-control" id="lastName" placeholder="Enter your last name" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="phone">Phone</label>
                        <input type="number" name="invoice_phone" class="form-control" id="phone" placeholder="Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="cellphone">Cell Phone</label>
                        <input type="number" name="invoice_cell" class="form-control" id="cellphone" placeholder="Cell Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="email">School E-mail</label>
                        <input type="email" name="invoice_email" class="form-control" id="email" placeholder="School E-mail" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="schoolname">School Name</label>
                        <input type="text" name="invoice_schoolname" class="form-control" id="schoolname" placeholder="School Name" >
                    </div>
                    <div class="col-md-6">
                        <label for="schooladdress">School Address</label>
                        <input type="text" name="invoice_schooladdress" class="form-control" id="schooladdress" placeholder="School Address" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="city">City</label>
                        <input type="text" name="invoice_city" class="form-control" id="city" placeholder="City" >
                    </div>
                    <div class="col-md-4">
                        <label for="state">State</label>
                        <input type="text" name="invoice_state" class="form-control" id="state" placeholder="State" >
                    </div>
                    <div class="col-md-4">
                        <label for="zip">Zip</label>
                        <input type="number" name="invoice_zip" class="form-control" id="zip" placeholder="Zip" >
                    </div>
                </div>
            </div>
            <div class="mb-4 allfields purchaseorder-allfields">
                <h4>School and Contact Information</h4>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="teacher">Person in charge of the Purchase Order</label>
                        <input type="text" name="purchase_teacher" class="form-control" id="teacher" placeholder="Person in charge of the Purchase Order" >
                    </div>
                    <div class="col-md-4">
                        <label for="firstName">First Name</label>
                        <input type="text" name="purchase_firstname" class="form-control" id="firstName" placeholder="Enter your first name" >
                    </div>
                    <div class="col-md-4">
                        <label for="lastName">Last Name</label>
                        <input type="text" name="purchase_lastname" class="form-control" id="lastName" placeholder="Enter your last name" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="phone">Phone</label>
                        <input type="number" name="purchase_phone" class="form-control" id="phone" placeholder="Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="cellphone">Cell Phone</label>
                        <input type="number" name="purchase_cell" class="form-control" id="cellphone" placeholder="Cell Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="email">School E-mail</label>
                        <input type="email" name="purchase_email" class="form-control" id="email" placeholder="School E-mail" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="schoolname">School Name</label>
                        <input type="text" name="purchase_schoolname" class="form-control" id="schoolname" placeholder="School Name" >
                    </div>
                    <div class="col-md-6">
                        <label for="schooladdress">School Address</label>
                        <input type="text" name="purchase_schooladdress" class="form-control" id="schooladdress" placeholder="School Address" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="city">City</label>
                        <input type="text" name="purchase_city" class="form-control" id="city" placeholder="City" >
                    </div>
                    <div class="col-md-4">
                        <label for="state">State</label>
                        <input type="text" name="purchase_state" class="form-control" id="state" placeholder="State" >
                    </div>
                    <div class="col-md-4">
                        <label for="zip">Zip</label>
                        <input type="number" name="purchase_zip" class="form-control" id="zip" placeholder="Zip" >
                    </div>
                </div>
            </div>
            <div class="mb-4 allfields echeck-allfields">
                <h4>School and Contact Information</h4>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="teacher">Person in charge (Title)</label>
                        <input type="text" name="echeck_personcharge" class="form-control" id="teacher" placeholder="Person in charge (Title)" >
                    </div>
                    <div class="col-md-4">
                        <label for="firstName">First Name</label>
                        <input type="text" name="echeck_firstname" class="form-control" id="firstName" placeholder="Enter your first name" >
                    </div>
                    <div class="col-md-4">
                        <label for="lastName">Last Name</label>
                        <input type="text" name="echeck_lastname" class="form-control" id="lastName" placeholder="Enter your last name" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="phone">Phone</label>
                        <input type="number" name="echeck_phone" class="form-control" id="phone" placeholder="Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="cellphone">Cell Phone</label>
                        <input type="number" name="echeck_cell" class="form-control" id="cellphone" placeholder="Cell Phone" >
                    </div>
                    <div class="col-md-4">
                        <label for="email">School E-mail</label>
                        <input type="email" name="echeck_email" class="form-control" id="email" placeholder="School E-mail" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="schooladdress">School Address</label>
                        <input type="text" name="echeck_schooladdress" class="form-control" id="schooladdress" placeholder="School Address" >
                    </div>
                    <div class="col-md-3">
                        <label for="city">City</label>
                        <input type="text" name="echeck_city" class="form-control" id="city" placeholder="City" >
                    </div>
                    <div class="col-md-3">
                        <label for="state">State</label>
                        <input type="text" name="echeck_state" class="form-control" id="state" placeholder="State" >
                    </div>
                    <div class="col-md-2">
                        <label for="zip">Zip</label>
                        <input type="number" name="echeck_zip" class="form-control" id="zip" placeholder="Zip" >
                    </div>
                </div>
                <div class="mb-4 billingsec">
                    <fieldset class="form-group">
                        <div class="form-radio">
                            <input class="form-radio-input account" type="radio" name="echeck_account" value="Checking"  checked>
                            <span class="checkmark"></span>
                            <label class="form-check-label" for="account">Checking Account</label>
                        </div>
                        <div class="form-radio">
                            <input class="form-radio-input account" type="radio" name="echeck_account" value="Saving" >
                            <span class="checkmark"></span>
                            <label class="form-check-label" for="account">Saving Account</label>
                        </div>
                    </fieldset>
                </div>
                <div class="form-group row routine-lab">
                    <div class="col-md-3">
                        <label for="CheckingRoutineNumber">Checking Routine Number</label>
                        <input type="text" name="echeck_routinenumber" class="form-control" id="" placeholder="Checking Routine Number" >
                    </div>
                    <div class="col-md-3">
                        <label for="CheckAccountNumber">Check Account Number</label>
                        <input type="text" name="echeck_accountnumber" class="form-control" id="" placeholder="Check Account Number" >
                    </div>
                </div>
            </div>

            
            <div class="mb-4 allfields creditcard-allfields creditcard-chks">
                <h4>Credit card Payment Information</h4>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="teacher">Name on card</label>
                        <input type="text" name="ccpi_cardname" class="form-control" id="teacher" placeholder="Name on card" >
                    </div>
                    <div class="col-md-4">
                        <label for="firstName">First Name</label>
                        <input type="text" name="ccpi_firstname" class="form-control" id="firstName" placeholder="Enter your first name" >
                    </div>
                    <div class="col-md-4">
                        <label for="lastName">Last Name</label>
                        <input type="text" name="ccpi_lastname" class="form-control" id="lastName" placeholder="Enter your last name" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-5">
                        <label for="cardnumber">Card Number</label>
                        <input type="text" name="ccpi_cardnumber" class="form-control" id="cardnumber" placeholder="Card Number" >
                    </div>
                    <div class="col-md-2">
                        <label for="expirationdate">Expiration Date</label>
                        <input type="text" name="ccpi_expirationdate" class="form-control" id="expirationdate" placeholder="Expiration Date" >
                    </div>
                    <div class="col-md-2">
                        <label for="SecurityCode">Security Code</label>
                        <input type="text" name="ccpi_securitycode" class="form-control" id="SecurityCode" placeholder="Security Code" >
                    </div>
                    <div class="col-md-3">
                        <label for="PaymentAmount">Payment Amount</label>
                        <input type="number" name="ccpi_amount" class="form-control" id="PaymentAmount" placeholder="Payment Amount" >
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="billingaddress">Billing Address</label>
                        <input type="text" name="ccpi_billaddress" class="form-control" id="billingaddress" placeholder="Billing Address" >
                    </div>
                    <div class="col-md-3">
                        <label for="city">City</label>
                        <input type="text" name="ccpi_city" class="form-control" id="city" placeholder="City" >
                    </div>
                    <div class="col-md-3">
                        <label for="state">State</label>
                        <input type="text" name="ccpi_state" class="form-control" id="state" placeholder="State" >
                    </div>
                    <div class="col-md-2">
                        <label for="zip">Zip</label>
                        <input type="number" name="ccpi_zip" class="form-control" id="zip" placeholder="Zip" >
                    </div>
                </div>
            </div>
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary cstm-btn">Submit</button>
            <span class="message"></span>
        </form>
    </div>

</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>

    jQuery(document).ready(function($) {
        $('.check-box-list').hide();
        $('.sendinvoice-chks').show();
        $('.allfields').hide();
        $('.sendinvoice-allfields').show();
        
        $("input[name$='communication']").click(function() {
            var payway = $(this).data('type');
            // alert(payway);
            $(this).parent().addClass('active');
            $('.check-box-list').hide();
            $('.'+payway+'-chks').show();
            $('.allfields').hide();
            $('.'+payway+'-allfields').show();
        });


        // Delegate event to handle dynamic elements
        $('#bookingshows').on('click', '.remove-row', function() {

            var showid = $(this).data('id');
            var showdate = $(this).data('date');
            var showtime = $(this).data('time');

            $(this).closest('.booking-row').remove(); // Remove the entire booking row
        
            var data = {
                action: 'remove_reserve_show', // This is the action we hooked into in PHP                  
                showid: showid,
                showdate: showdate,
                showtime: showtime,
            };

            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // Use localized AJAX URL
                data:data,
                success: function(data) {
                    updateNetTotal();
                }
            });
        
        });


    // Function to calculate and update the total for a specific row
        function updateRowTotal(row) {
            var grosstotal = 0; // Initialize the gross total for this row

            // Iterate over each .seatbook input field within the specified row
            $(row).find('.seatbook').each(function() {
                var seatnum = $(this).val(); // Get the value of the current field
                var seatper = $(this).data('seatper'); // Get the price per seat from data attribute
                
                // Calculate the total for the current field
                var total = parseInt(seatnum) || 0; // Convert seatnum to integer, default to 0 if NaN
                var cost = total * parseFloat(seatper) || 0; // Convert seatper to float and calculate cost
                
                // Add the cost to the gross total for this row
                grosstotal += cost;
            });

            // Update the grosstotal element within this row
            $(row).find('.grosstotal').text('$' + grosstotal.toFixed(2));
            $(row).find('input[name="grosstotal[]"]').val(grosstotal.toFixed(2));
        }

        // Function to calculate and update the net total for all rows
        function updateNetTotal() {
            var netTotal = 0; // Initialize the net total

            // Iterate over each .booking-row
            $('.booking-row').each(function() {
                var rowTotal = $(this).find('.grosstotal').text(); // Get the gross total for the current row
                var rowTotalValue = parseFloat(rowTotal.replace('$', '')) || 0; // Convert to float
                netTotal += rowTotalValue; // Add the row total to the net total
            });

            // Update the nettotal element
            $('.nettotal').text('$' + netTotal.toFixed(2));
            $('.netamt').val(netTotal.toFixed(2));
        }

        // Attach keyup event to each input field with class .seatbook
        $(document).on('keyup', '.seatbook', function() {
            var row = $(this).closest('.booking-row'); // Find the closest .booking-row ancestor
            updateRowTotal(row); // Update the total for this row
            updateNetTotal(); // Update the net total after updating the row total
        });

        // Call updateRowTotal and updateNetTotal on page load for each row
        $('.booking-row').each(function() {
            updateRowTotal(this);
        });
        updateNetTotal();


        $('#reserveform').submit(function(event) {
            event.preventDefault(); // Prevent the default form submission

            var formData = $(this).serialize(); // Serialize the form data

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>', // This is a global variable in WordPress that contains the URL for AJAX requests
                type: 'POST',
                data: {
                    action: 'save_form_data', // The action name to identify the request
                    form_data: formData
                },
                success: function(response) {
                    $('.message').text('Shows Booking Successfully.');
                    setTimeout(function() {
                        window.location.href = 'https://elvirainfotech.online/shows-reservation/';
                    }, 3000);
                    console.log(response);
                },
                error: function(xhr, status, error) {
                    alert('An error occurred.');
                    console.log(xhr.responseText);
                }
            });
        });
    });
</script>
</body>
</html>
