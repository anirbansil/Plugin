<?php
register_activation_hook(__FILE__, 'create_tables');

function create_tables() {
    global $wpdb;
    
    // Define table names
    $booking_table_name = $wpdb->prefix . 'booking_shows';
    // $net_total_table_name = $wpdb->prefix . 'net_total';

    // Define character set and collation
    $charset_collate = $wpdb->get_charset_collate();

    // SQL for creating the booking details table
    $booking_table_sql = "CREATE TABLE $booking_table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        showid bigint(20) NOT NULL,
        showname varchar(255) NOT NULL,
        datetime varchar(255) NOT NULL,
        location varchar(255) NOT NULL,
        seatprice float NOT NULL,
        students int(11) NOT NULL,
        teachers int(11) NOT NULL,
        para int(11) NOT NULL,
        chaperones int(11) NOT NULL,
        others int(11) NOT NULL,
        grosstotal float NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // SQL for creating the net total table
    // $net_total_table_sql = "CREATE TABLE $net_total_table_name (
    //     id mediumint(9) NOT NULL AUTO_INCREMENT,
    //     total float NOT NULL,
    //     PRIMARY KEY  (id)
    // ) $charset_collate;";

    // Include the WordPress upgrade script
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    // Create the tables
    dbDelta( $booking_table_sql );
    // dbDelta( $net_total_table_sql );
}




add_action( 'init', 'ht_custom_post_shows' );

function ht_custom_post_shows() {
	
    $labels = array(
        'name' => __( 'Shows', 'Post Type General Name', 'shows' ),
        'singular_name' => __( 'Show', 'Post Type General Name', 'shows' ),
        'menu_name' => __( 'Shows', 'shows' ),
        'name_admin_bar' => __( 'Shows', 'shows' ),
        'archives' => __( 'Show Archives', 'shows' ),
        'attributes' => __( 'Show Attributes', 'shows' ),
        'parent_item_colon' => __( 'Parent show', 'shows' ),
        'all_items' => __( 'All shows', 'shows' ),
        'add_new' => __( 'New show', 'shows' ),
        'add_new_item' => __( 'Add New show', 'shows' ),
        'edit_item' => __( 'Edit show', 'shows' ),
        'update_item' => __( 'Update show', 'shows' ),
        'new_item' => __( 'New show', 'shows' ),
        'view_item' => __( 'View shows', 'shows' ),
        'search_items' => __( 'Search shows', 'shows' ),
        'not_found' =>  __( 'No shows found', 'shows' ),
        'not_found_in_trash' => __( 'No shows found in Trash'),
        'featured_image' => __( 'Featured Image', 'shows' ),
        'set_featured_image' => __( 'Set Featured Image', 'shows' ),
        'remove_featured_image' => __( 'Remove Featured Image', 'shows' ),
        'use_featured_image' => __( 'Use as Featured Image', 'shows' ),
        'insert_into_item' => __( 'Insert Into show', 'shows' ),
        'uploaded_to_this_item' => __( 'Uploaded To This show', 'shows' ),
        'items_list' => __( 'Shows list', 'shows' ),
        'items_list_navigation' => __( 'Shows list navigation', 'shows' ),
        'filter_items_list' => __( 'Filter shows List', 'shows' ),
    );
	
    $args = array(
        'labels'                => $labels,
        'description'           => 'Holds our shows post specific data',
        'public'                => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-welcome-widgets-menus',
        'supports'              => array( 'title', 'editor', 'thumbnail' ), // 'excerpt', 'comments', 'custom-fields'
        'has_archive'           => true,
        'hierarchical'          => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'query_var'             => true,
        'can_export'            => true,
        'exclude_from_search'   => false,
        'show_in_rest'          => true,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'rewrite'               => array( 'slug' => 'shows' ),
    );
	
    register_post_type('shows', $args);

    // Register Custom Taxonomy
    $taxonomy_labels = array(
        'name'              => __( 'Show Types', 'shows' ),
        'singular_name'     => __( 'Show Type', 'shows' ),
        'search_items'      => __( 'Search Show Types', 'shows' ),
        'all_items'         => __( 'All Show Types', 'shows' ),
        'parent_item'       => __( 'Parent Show Type', 'shows' ),
        'parent_item_colon' => __( 'Parent Show Type:', 'shows' ),
        'edit_item'         => __( 'Edit Show Type', 'shows' ),
        'update_item'       => __( 'Update Show Type', 'shows' ),
        'add_new_item'      => __( 'Add New Show Type', 'shows' ),
        'new_item_name'     => __( 'New Show Type Name', 'shows' ),
        'menu_name'         => __( 'Show Types', 'shows' ),
    );

    $taxonomy_args = array(
        'labels'            => $taxonomy_labels,
        'hierarchical'      => true, // Set to true to create a category-like taxonomy
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'show-type' ),
        'show_in_rest'      => true, // Enable for Gutenberg
    );

    register_taxonomy( 'show_type', array( 'shows' ), $taxonomy_args );

    // Add Meta Boxes
    add_action('add_meta_boxes', 'ht_add_show_meta_boxes');

    add_action('admin_menu', 'ht_add_shows_submenu');
}


function ht_add_shows_submenu() {
    add_submenu_page(
        'edit.php?post_type=shows', // Parent slug
        __('Show Booking Records', 'shows'), // Page title
        __('Booking Records', 'shows'),       // Menu title
        'manage_options',              // Capability
        'shows-booking-records',              // Menu slug
        'ht_show_booking_records_page'        // Function to display the settings page
    );
    add_submenu_page("edit.php?post_type=shows", NULL, NULL, "manage_options", "show-booking-record-details", "ht_show_booking_records_details_page" );

    // Adding a settings submenu under the Settings menu
    add_submenu_page(
        'edit.php?post_type=shows', // Parent slug
        __('Show Booking Settings', 'shows'), // Page title
        __('Settings', 'shows'),       // Menu title
        'manage_options',              // Capability
        'shows-booking-settings',              // Menu slug
        'ht_show_booking_settings_page'        // Function to display the settings page
    );
}

// Callback function to display the content of the admin page
function ht_show_booking_records_page() {
    include plugin_dir_path(__FILE__) . '../view/admin/booking-records.php';
}
function ht_show_booking_records_details_page(){
    include plugin_dir_path(__FILE__) . '../view/admin/booking-record-details.php';
}
function ht_show_booking_settings_page() {
    include plugin_dir_path(__FILE__) . '../view/admin/settings.php'; // Update this path as needed
}


function ht_add_show_meta_boxes() {
    add_meta_box('show_meta', __( 'Show Details', 'shows' ), 'ht_show_meta_callback', 'shows', 'normal', 'high');
}



function ht_show_meta_callback($post) {
    // Add nonce for security
    wp_nonce_field('ht_show_meta_box', 'ht_show_meta_nonce');

    // Retrieve existing values
    $show_sub_title = get_post_meta($post->ID, '_show_sub_title', true);
    $show_date = get_post_meta($post->ID, '_show_date', true);
    $show_time = get_post_meta($post->ID, '_show_time', true);
    $seat_limit = get_post_meta($post->ID, '_seat_limit', true); // Retrieve seat limits
    $show_price = get_post_meta($post->ID, '_show_price', true);
    $show_location = get_post_meta($post->ID, '_show_location', true);
    $study_guide_url = get_post_meta($post->ID, '_study_guide', true); // Retrieve file URL
    $study_guide_name = basename($study_guide_url); // Extract the file name

    // Output the fields
    $data = compact('show_sub_title', 'show_date', 'show_time', 'seat_limit', 'show_price', 'show_location', 'study_guide_url', 'study_guide_name');

    // Include the HTML file
    include plugin_dir_path(__FILE__) . '../view/admin/meta-box-form.php';
}




// Save Meta Fields
add_action('save_post', 'ht_save_show_meta');

function ht_save_show_meta($post_id) {
    // Check nonce for security
    if (!isset($_POST['ht_show_meta_nonce']) || !wp_verify_nonce($_POST['ht_show_meta_nonce'], 'ht_show_meta_box')) {
        return;
    }

    // Check for autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Save the data
    if (isset($_POST['show_sub_title'])) {
        update_post_meta($post_id, '_show_sub_title', sanitize_text_field($_POST['show_sub_title']));
    }
    if (isset($_POST['show_date'])) {
        update_post_meta($post_id, '_show_date', sanitize_text_field($_POST['show_date']));
    }
    if (isset($_POST['show_time'])) {
        $times = array_map('sanitize_text_field', $_POST['show_time']);
        update_post_meta($post_id, '_show_time', $times);
    }
    if (isset($_POST['seat_limit'])) {
        $limits = array_map('intval', $_POST['seat_limit']);
        update_post_meta($post_id, '_seat_limit', $limits);
    }
    if (isset($_POST['show_price'])) {
        update_post_meta($post_id, '_show_price', sanitize_text_field($_POST['show_price']));
    }
    if (isset($_POST['show_location'])) {
        update_post_meta($post_id, '_show_location', sanitize_text_field($_POST['show_location']));
    }

    // Handle file URL
    if (isset($_POST['study_guide'])) {
        $study_guide_url = esc_url_raw($_POST['study_guide']);
        update_post_meta($post_id, '_study_guide', $study_guide_url);
    }
}




function shows_list_shortcode(){

    $php_html_file_path = plugin_dir_path(__FILE__) . '../view/frontend/shows.php';
    ob_start();
    include $php_html_file_path;
    return ob_get_clean();
}
add_shortcode('shows-list', 'shows_list_shortcode');


function reserve_form_shortcode(){

    $php_html_file_path = plugin_dir_path(__FILE__) . '../view/frontend/reserve.php';
    ob_start();
    include $php_html_file_path;
    return ob_get_clean();
}
add_shortcode('reserve-form', 'reserve_form_shortcode');


add_filter('template_include', 'ht_load_show_template');

function ht_load_show_template($template) {
    if (is_singular('shows')) { // Check if it's a single 'shows' post
        // Get the path to your custom single template
        $plugin_dir = plugin_dir_path(__FILE__);
        return $plugin_dir . '../view/frontend/single-shows.php'; // Adjust the path as necessary
    }
    return $template; // Return the original template if not a 'shows' post
}


function ht_save_reserved_page() {
    // Check if our nonce is set and valid
    if ( ! isset($_POST['rpp_reserved_page_nonce']) || ! wp_verify_nonce($_POST['rpp_reserved_page_nonce'], 'rpp_reserved_page_action') ) {
        wp_die(__('Nonce verification failed.', 'shows'));
    }

    // Check if the user has permission to manage options
    if ( ! current_user_can('manage_options') ) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'shows'));
    }

    // Sanitize and save the selected page
    $reserved_page = isset($_POST['rpp_reserved_page']) ? intval($_POST['rpp_reserved_page']) : 0;
    update_option('rpp_reserved_page', $reserved_page);

    // Redirect back to the settings page with a success message
    wp_redirect(add_query_arg('settings-updated', 'true', wp_get_referer()));
    exit;
}

// Hook the function to handle the form submission
add_action('admin_post_save_rpp_reserved_page', 'ht_save_reserved_page');


function start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'start_session');


function fcp_handle_item_redirect() {

    // $showid = $_POST['showid'];  
    // $showdate = $_POST['showdate'];
    // $showtime = $_POST['showtime'];
    // echo $showid.", ".$showdate.", ".$showtime;
    // echo show_reservation_base_path ."sessions-master/database.class.php";
    // echo show_reservation_base_path ."sessions-master/mysql.sessions.php";
    // die();
    if(!class_exists('Session')){
        require_once show_reservation_base_path ."sessions-master/database.class.php";  //Include MySQL database class
        // die();
        require_once show_reservation_base_path ."sessions-master/mysql.sessions.php";  //Include PHP MySQL sessions
        // Ensure session is started
        $session = new Session();
    }

    // Store all post data in the session
    // unset($_SESSION['show_details_data']);
    if (!isset($_SESSION['show_details_data'])) {
        $_SESSION['show_details_data'] = array();
    }
    
    // New show details from POST data
    $new_show_details = array(
        'show_id' => $_POST['showid'],
        'show_date' => $_POST['showdate'],
        'show_time' => $_POST['showtime']
    );

    function existsInArray($array, $newData) {
        foreach ($array as $item) {
            // Compare each item in the array with the new data
            if ($item['show_id'] === $newData['show_id'] &&
                $item['show_date'] === $newData['show_date'] &&
                $item['show_time'] === $newData['show_time']) {
                return true; // Data exists
            }
        }
        return false; // Data does not exist
    }
    
    // Check if new show details already exist in the session array
    if (!existsInArray($_SESSION['show_details_data'], $new_show_details)) {
        // Append the new show details to the session array
        array_push($_SESSION['show_details_data'], $new_show_details);
    }
    
    // Append the new show details to the session array

    $redirect_url = "https://elvirainfotech.online/shows-reservation/reserve/";
    
    // You can customize the URL as needed. Here we're redirecting to the item's single page.

    if ($redirect_url) {
        wp_send_json(array('redirect_url' => $redirect_url));
    } else {
        wp_send_json_error(array('message' => 'Failed to retrieve redirect URL.'));
    }
}
add_action('wp_ajax_fcp_redirect_item', 'fcp_handle_item_redirect');
add_action('wp_ajax_nopriv_fcp_redirect_item', 'fcp_handle_item_redirect');


function remove_reserve_show(){

    $newData = array(
        'show_id' => $_POST['showid'],
        'show_date' => $_POST['showdate'],
        'show_time' => $_POST['showtime']
    );
    $session_data = $_SESSION['show_details_data'];
    unset($_SESSION['show_details_data']);
    if (!isset($_SESSION['show_details_data'])) {
        $_SESSION['show_details_data'] = array();
    }
    foreach ($session_data as $sesData) {
        // Compare each item in the array with the new data
        if ($sesData['show_id'] !== $newData['show_id'] &&
            $sesData['show_date'] !== $newData['show_date'] &&
            $sesData['show_time'] !== $newData['show_time']) {
                
            $new_show_details = array(
                'show_id' => $_POST['showid'],
                'show_date' => $_POST['showdate'],
                'show_time' => $_POST['showtime']
            );
            array_push($_SESSION['show_details_data'], $new_show_details);
        }
    }
    $redirect_url = "https://elvirainfotech.online/shows-reservation/reserve/";
    
    // You can customize the URL as needed. Here we're redirecting to the item's single page.

    if ($redirect_url) {
        wp_send_json(array('redirect_url' => $redirect_url));
    } else {
        wp_send_json_error(array('message' => 'Failed to retrieve redirect URL.'));
    }
}
add_action('wp_ajax_remove_reserve_show', 'fcp_handle_item_redirect');
add_action('wp_ajax_nopriv_remove_reserve_show', 'fcp_handle_item_redirect');


function save_form_data() {
    global $wpdb;

    // Verify nonce for security (optional but recommended)
    // if ( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'your_nonce_action') ) {
    //     wp_send_json_error('Invalid nonce');
    // }

    $booking_records = 'booking_records'; // Replace with your custom table name

    $booking_shows = 'booking_shows'; // Replace with your custom table name

    // Parse the form data
    parse_str($_POST['form_data'], $form_data);
    // $card = sanitize_text_field($form_data['ccpi_cardname']);
    // echo $card;

    $showid = $form_data['showid'];
    $shownames = $form_data['showname'];
    $datetimes = $form_data['datetime'];
    $locations = $form_data['location'];
    $seatprices = $form_data['seatprice'];
    $grades = $form_data['grade'];
    $students = $form_data['students'];
    $teachers = $form_data['teachers'];
    $para = $form_data['para'];
    $chaperones = $form_data['chaperones'];
    $others = $form_data['others'];
    $grosstotals = $form_data['grosstotal'];

    $paymenttype = $form_data['communication'];


    if ($paymenttype == "send invoice") {
        $paymentdetails = array(
            'invoice_policy_one'        => sanitize_text_field($form_data['invoice_policy_one']),
            'invoice_policy_two'       => sanitize_text_field($form_data['invoice_policy_two']),
            'invoice_teacher'        => sanitize_text_field($form_data['invoice_teacher']),
            'invoice_firstname'       => sanitize_text_field($form_data['invoice_firstname']),
            'invoice_lastname'        => sanitize_text_field($form_data['invoice_lastname']),
            'invoice_phone'      => sanitize_text_field($form_data['invoice_phone']),
            'invoice_cell'  => sanitize_text_field($form_data['invoice_cell']),
            'invoice_email'    => sanitize_text_field($form_data['invoice_email']),
            'invoice_schoolname'           => floatval($form_data['invoice_schoolname']),
            'invoice_schooladdress'  => sanitize_text_field($form_data['invoice_schooladdress']),
            'invoice_city'             => sanitize_text_field($form_data['invoice_city']),
            'invoice_state'            => sanitize_text_field($form_data['invoice_state']),
            'invoice_zip'              => intval($form_data['invoice_zip']),
        );
    }elseif ($paymenttype == "purchase order") {
        $paymentdetails = array(
            'purchase_policy_one'        => sanitize_text_field($form_data['purchase_policy_one']),
            'purchase_policy_two'       => sanitize_text_field($form_data['purchase_policy_two']),
            'purchase_teacher'        => sanitize_text_field($form_data['purchase_teacher']),
            'purchase_firstname'       => sanitize_text_field($form_data['purchase_firstname']),
            'purchase_lastname'        => sanitize_text_field($form_data['purchase_lastname']),
            'purchase_phone'      => sanitize_text_field($form_data['purchase_phone']),
            'purchase_cell'  => sanitize_text_field($form_data['purchase_cell']),
            'purchase_email'    => sanitize_text_field($form_data['purchase_email']),
            'purchase_schoolname'           => floatval($form_data['purchase_schoolname']),
            'purchase_schooladdress'  => sanitize_text_field($form_data['purchase_schooladdress']),
            'purchase_city'             => sanitize_text_field($form_data['purchase_city']),
            'purchase_state'            => sanitize_text_field($form_data['purchase_state']),
            'purchase_zip'              => intval($form_data['purchase_zip']),
        );
    }elseif ($paymenttype == "e-check") {
        $paymentdetails = array(
            'echeck_policy_one'        => sanitize_text_field($form_data['echeck_policy_one']),
            'echeck_policy_two'       => sanitize_text_field($form_data['echeck_policy_two']),
            'echeck_personcharge'        => sanitize_text_field($form_data['echeck_personcharge']),
            'echeck_firstname'       => sanitize_text_field($form_data['echeck_firstname']),
            'echeck_lastname'        => sanitize_text_field($form_data['echeck_lastname']),
            'echeck_phone'      => sanitize_text_field($form_data['echeck_phone']),
            'echeck_cell'  => sanitize_text_field($form_data['echeck_cell']),
            'echeck_email'    => sanitize_text_field($form_data['echeck_email']),
            'echeck_schooladdress'           => floatval($form_data['echeck_schooladdress']),
            'echeck_city'  => sanitize_text_field($form_data['echeck_city']),
            'echeck_state'             => sanitize_text_field($form_data['echeck_state']),
            'echeck_zip'            => sanitize_text_field($form_data['echeck_zip']),
            'echeck_account'              => intval($form_data['echeck_account']),
            'echeck_routinenumber'            => sanitize_text_field($form_data['echeck_routinenumber']),
            'echeck_accountnumber'              => intval($form_data['echeck_accountnumber']),
        );
    }elseif ($paymenttype == "credit card") {
        $paymentdetails = array(
            'creditcard_policy_one'        => sanitize_text_field($form_data['ccpi_policy_one']),
            'creditcard_policy_two'       => sanitize_text_field($form_data['ccpi_policy_two']),
            'creditcard_card_name'        => sanitize_text_field($form_data['ccpi_cardname']),
            'creditcard_first_name'       => sanitize_text_field($form_data['ccpi_firstname']),
            'creditcard_last_name'        => sanitize_text_field($form_data['ccpi_lastname']),
            'creditcard_card_number'      => sanitize_text_field($form_data['ccpi_cardnumber']),
            'creditcard_expiration_date'  => sanitize_text_field($form_data['ccpi_expirationdate']),
            'creditcard_security_code'    => sanitize_text_field($form_data['ccpi_securitycode']),
            'creditcard_amount'           => floatval($form_data['ccpi_amount']),
            'creditcard_billing_address'  => sanitize_text_field($form_data['ccpi_billaddress']),
            'creditcard_city'             => sanitize_text_field($form_data['ccpi_city']),
            'creditcard_state'            => sanitize_text_field($form_data['ccpi_state']),
            'creditcard_zip'              => intval($form_data['ccpi_zip']),
        );
    }
    $paymentdetails_serialized = serialize($paymentdetails);

    $wpdb->insert(
        $booking_records,
        array(
            'pay_amount' => floatval($form_data['nettotal']),
            'payment_type' => sanitize_text_field($form_data['communication']),
            'payment_details' => $paymentdetails_serialized,
        )
    );
    $record_id = $wpdb->insert_id;


    for ($i = 0; $i < count($shownames); $i++) {
        $wpdb->insert(
            $booking_shows,
            array(
            'showid' => sanitize_text_field($showid[$i]),
            'booking_record_id' => $record_id,
            'showname' => sanitize_text_field($shownames[$i]),
            'datetime' => sanitize_text_field($datetimes[$i]),
            'location' => sanitize_text_field($locations[$i]),
            'seatprice' => floatval($seatprices[$i]),
            'students' => intval($students[$i]),
            'teachers' => intval($teachers[$i]),
            'para' => intval($para[$i]),
            'chaperones' => intval($chaperones[$i]),
            'others' => intval($others[$i]),
            'grosstotal' => floatval($grosstotals[$i])
            )
        );

        $booking_id = $wpdb->insert_id;
        // print_r($booking_table);
    }

    // // Insert data into the custom table
    // $result = $wpdb->insert($table_name, $data);

    if ($record_id !== false) {
        wp_send_json_success('Data saved successfully');
    } else {
        wp_send_json_error('Failed to save data');
    }

    wp_die(); // This is required to terminate immediately and return a proper response
}

add_action('wp_ajax_save_form_data', 'save_form_data');
add_action('wp_ajax_nopriv_save_form_data', 'save_form_data'); // Allow non-logged in users to access this action if needed


