<?php
/*
 * Plugin Name: Shows Reservation
 * Plugin URI: http://elvirainfotech.com/
 * Description: This plugin for shows reservation records maintain and shows booking form.
 * Author: Raihan Reza
 * Author URI: http://elvirainfotech.com/
 * Version: 1.0.0
 * Requires at least: 1.0
 * Tested up to: 4.8
 * Text Domain: shows-reservation
 * Copyright (c) 2024 Elvira Infotech
*/


require_once plugin_dir_path(__FILE__) . 'includes/functions.php';

define( 'show_reservation_base_path', plugin_dir_path( __FILE__ ) );
function ht_enqueue_styles() {
    // Enqueue the stylesheet
    wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css');
    wp_enqueue_style('your-plugin-style', plugin_dir_url(__FILE__) . 'assets/style.css');

    wp_enqueue_script('jquery');
    wp_localize_script('jquery', 'crud_obj', array('nonce' => wp_create_nonce('crud_nonce')));

}

add_action('wp_enqueue_scripts', 'ht_enqueue_styles');


function fcp_handle_item_redirect2() {

    echo "Hello";
    die();

    
}
add_action('wp_ajax_fcp_redirect_item2', 'fcp_handle_item_redirect2');
add_action('wp_ajax_nopriv_fcp_redirect_item2', 'fcp_handle_item_redirect2');

?>